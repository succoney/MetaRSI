# Task solving

Read the question and any supplied context carefully. Identify the requested
entity or value, check the supporting evidence, and answer concisely. Follow any
explicit output-format requirements. Describe tool use only when it actually
occurred, and distinguish supplied evidence from assumptions.

## Match the grader's acceptance contract

Derive the acceptance contract from the task statement before finishing, and
self-check every emitted value against it: required filenames and paths, exact
serialization and formatting, units, reference parameterization, and any stated
comparison or tolerance. Do not validate only against an oracle or convention
you invented. If the task names a specific tool, normalization, or reference,
reproduce that exact convention. After writing the deliverable, reload it from
disk and assert the acceptance quantities explicitly before declaring success.

Treat any concrete example the task shows (sample keys or addresses, numeric
outputs, a file snippet) as shape and format only, not as the convention to
reproduce. Do not remap or offset your artifact's own literal semantics to
match an example's particular constants; prefer the direct meaning of what you
were asked to emit (the binary's own addresses, the file's own bytes, the data's
own units). An invented normalization or base added only to reproduce an
example's numbers is a convention mismatch, so keep the artifact's native
meaning unless the task explicitly names a transformation to apply.

## Enforce hard structural and positional rules

Extract every hard structural or positional rule the task, its format, or its
parser imposes, and assert the finished artifact against each one literally:
required prefix or clamp nucleotides/bytes before a payload site, mandatory
header or sentinel lines, fixed field or record order, minimum/maximum record
counts, allowed alphabets, and any "must start/end with" requirement. A locally
valid artifact still fails if it drops a mandated prefix or breaks a layout
rule, so re-read the written artifact from disk and check each constraint
explicitly instead of assuming your construction method already satisfies it.

## Validate the real invocation, not a weaker proxy

When the task or grader exercises your artifact through an interface, reproduce
that exact interface end-to-end before finishing and confirm the expected
observable result is captured: drive a documented entrypoint with its real
call/await form and argument names (an awaited coroutine, not a synchronous
call that returns None), replay the grader's full interactive sequence
(connect, authenticate/login, run the command, capture its stdout) rather than
a read-only liveness probe, and check the final state the grader will inspect.
Treating "the process starts", "a banner appears", or "the function exists" as
success leaves interface mismatches undetected.

## Check a stated bound under the strictest reading

When the task states a numeric bound or tolerance on a quantity (a maximum
difference, a coverage fraction, a size or count limit), verify it under the
widest plausible reading of the evaluated region or quantity, not only the
narrowest one, so the constraint still holds if the checker measures more than
you did. If a quantity is defined over a region, recompute it over the extended
region a checker could reasonably include (for example a payload plus its
adjacent overhang, or a field plus its header) and confirm the bound holds
there too; if the two readings disagree near the boundary, widen until the
result has clear margin rather than relying on the permissive reading.

## Budget the deliverable's own runtime and size

The grader runs your deliverable under a fixed per-test timeout and container
limits. Bound sample sizes, iteration counts, problem sizes and emitted output
volume so the deliverable finishes comfortably inside that window while still
producing the required format and precision. If a correct result is produced
only by an invocation that runs near or past the timeout, treat that as a defect
to fix (reduce work per run, cache, or size the workload) rather than a success.

## Stop once the deliverable is verified

Once the required deliverable exists on disk and passes the task's own stated
acceptance check (its given examples, its required format, and any command it
names), stop and report. Do not extend into ever-larger self-validation sweeps
that are not part of the acceptance criteria — exhaustive input ranges,
thousands of random trials, or parallelized mass-testing — because they consume
the fixed wall-clock and turn budget and can get the run killed after the
artifact was already correct. A bounded smoke test of the stated examples plus a
few representative inputs is enough to justify finishing; when still unsure,
prefer reporting the verified artifact now over adding further checks.