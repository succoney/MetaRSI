"""Bounded pre-final acceptance self-audit (a finalization gate).

Reusable mechanism targeting the reported failure mode
``grader_oracle_convention_mismatch``: runs ship a locally consistent artifact
that was checked against an *invented* convention instead of the task's actual
acceptance contract. Passive skill text did not change behaviour, so this hook
turns the success habit ``grader_flow_replay`` / ``independent_output_verification``
into an enforced step: before the runtime accepts a final answer, one bounded
side completion re-reads the task text and the commands the run actually
executed, and reports only *verifiable* contract gaps (missing deliverable path,
the task's named acceptance command/interface never actually run, a task-named
normalization/reference/tool not reproduced, or a stated hard structural rule
never asserted on the written artifact).

The gate is self-limiting: it audits at most once per run, defers immediately
when the continuation budget is already spent, and accepts whenever the audit
is unavailable (side model error/budget) or returns anything other than an
explicit ``UNMET`` verdict. It never changes the grader, model, token budget or
score accounting, and needs no task-specific constants.
"""

from __future__ import annotations

import json

# Keep the audit cheap and bounded: one side completion, small output.
_AUDIT_MAX_TOKENS = 400
_COMMAND_WINDOW = 24
_MAX_COMMAND_CHARS = 180
_MAX_QUESTION_CHARS = 4000
_MAX_ANSWER_CHARS = 2000
_MAX_FEEDBACK_CHARS = 600

_AUDIT_PROMPT = """\
You are auditing whether a coding agent satisfied the EXACT acceptance contract \
stated in its task. You get the task text, a compact log of the shell commands \
the run actually executed, and the agent's proposed final summary.

Task text:
---
{question}
---

Shell commands the run actually executed (most recent last):
---
{commands}
---

Proposed final summary:
---
{answer}
---

Report ONLY mismatches between the task's stated contract and what the run \
demonstrably did, checking in particular:
1. A required output path/filename was not created, or not at the stated location.
2. The acceptance command or callable interface the task names was never actually \
run (or run in the wrong sync/async/argument form), so its observable result is \
unproven.
3. A task-named normalization, serializer, tool, reference base, or parameter \
convention was not reproduced, i.e. the agent validated against its own invented \
convention.
4. A hard structural/positional rule the task states (required prefix or clamp, \
field/record order, counts, alphabet) was never asserted on the written artifact.

If and only if one of these is clearly unmet, output a single line starting with \
"UNMET:" followed by the single most important corrective action as a direct \
instruction to the agent (max 60 words). Otherwise output exactly "OK".
"""


def _command_log(ctx) -> str:
    lines: list[str] = []
    for rec in getattr(ctx, "tool_history", []) or []:
        if getattr(rec, "executed_name", None) != "shell":
            continue
        cmd = (getattr(rec, "executed_args", None) or {}).get("command") or ""
        cmd = " ".join(str(cmd).split())
        status = ""
        try:
            parsed = json.loads(rec.result_preview)
            if isinstance(parsed, dict):
                status = " (exit %s" % parsed.get("exit_code")
                if parsed.get("timed_out"):
                    status += ", TIMED_OUT"
                status += ")"
        except Exception:
            pass
        if len(cmd) > _MAX_COMMAND_CHARS:
            cmd = cmd[:_MAX_COMMAND_CHARS] + "..."
        lines.append("- %s%s" % (cmd, status))
    if not lines:
        return "(no shell commands were run)"
    return "\n".join(lines[-_COMMAND_WINDOW:])


async def before_final(answer, ctx):
    """Gate finalization on one bounded acceptance audit.

    Returns ``{"action": "continue", "feedback": ...}`` to demand a fix, else
    ``None`` to accept (the framework's default accept path).
    """
    state = ctx.state["contract_audit"]
    if state.get("done"):
        return None
    if ctx.remaining_turns <= 0 or ctx._final_continues >= ctx._final_continue_max:
        # No budget left to act on a finding; accept rather than waste a turn.
        return None
    state["done"] = True

    prompt = _AUDIT_PROMPT.format(
        question=(ctx.question or "")[:_MAX_QUESTION_CHARS],
        commands=_command_log(ctx),
        answer=(answer or "")[:_MAX_ANSWER_CHARS],
    )
    verdict = await ctx.side_text(
        prompt, purpose="contract_audit", max_tokens=_AUDIT_MAX_TOKENS
    )
    if not verdict:
        return None
    verdict = verdict.strip()
    ctx.trace.event("contract_audit", verdict=verdict[:_AUDIT_MAX_TOKENS])
    if not verdict.upper().startswith("UNMET"):
        return None

    finding = verdict.split(":", 1)[1].strip() if ":" in verdict else verdict
    feedback = (
        "Before finishing, close this acceptance-contract gap surfaced by an "
        "independent audit of your task text and commands: " + finding
    )[:_MAX_FEEDBACK_CHARS]
    return {"action": "continue", "feedback": feedback}