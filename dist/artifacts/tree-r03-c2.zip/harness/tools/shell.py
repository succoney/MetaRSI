"""A bounded shell call in the native MiniAgent's task environment.

Execution contract (portability/fidelity):

  * Commands run under ``bash -o pipefail -c`` when bash is available, so a
    pipeline reports the failing stage's status instead of the status of the
    last (often ``head``) stage. ``/bin/sh`` is used only as a fallback when
    bash is absent.
  * The child's real exit code is returned. When the executed command ends in
    a pipeline, the per-stage ``PIPESTATUS`` vector is appended to the result
    as ``pipe_status`` so a masked failure is visible.
  * The command runs in its own session with default SIGINT/SIGTERM/SIGPIPE
    dispositions, so externally delivered signals reach the child instead of
    being swallowed by an inherited ignore disposition.
"""

import asyncio
import json
import math
import os
import signal
from pathlib import Path

_OUTPUT_LIMIT = 32 * 1024

# Reset inherited signal dispositions to their defaults in the child shell so
# background children do not inherit SIG_IGN for SIGINT/SIGTERM/SIGPIPE.
_TRAP_RESET = "trap - INT TERM PIPE 2>/dev/null\n"

# Appended after the user's command. Captures PIPESTATUS *before* running any
# other command (an assignment would otherwise reset it), reports the stages on
# a dedicated fd, then exits with the pipefail-style status (rightmost non-zero
# stage, or zero).
_STATUS_CAPTURE = (
    "\n__frs_ps=(\"${PIPESTATUS[@]}\")\n"
    "__frs_rc=0\n"
    "for __frs_s in \"${__frs_ps[@]}\"; do\n"
    "  if [ \"$__frs_s\" -ne 0 ]; then __frs_rc=$__frs_s; fi\n"
    "done\n"
    "printf \"%s\" \"${__frs_ps[*]}\" >&{fd}\n"
    "exit \"$__frs_rc\"\n"
)


def _bash_path():
    for candidate in ("/bin/bash", "/usr/bin/bash"):
        if os.path.exists(candidate):
            return candidate
    return None


async def call(args, ctx) -> str:
    command = args.get("command")
    if not isinstance(command, str) or not command.strip():
        raise ValueError("command must be a non-empty string")
    timeout = args.get("timeout", 60)
    if type(timeout) not in (int, float) or not math.isfinite(timeout) or timeout <= 0:
        raise ValueError("timeout must be a positive finite number")
    cwd = args.get("cwd", ".")
    if not isinstance(cwd, str) or not cwd:
        raise ValueError("cwd must be a non-empty path")
    directory = (ctx.working_dir / Path(cwd)).resolve(strict=True)

    bash = _bash_path()

    loop = asyncio.get_running_loop()
    read_fd, write_fd = os.pipe()
    os.set_blocking(read_fd, False)
    output = bytearray()
    truncated = False

    # Dedicated pipe for the pipeline stage statuses; only used on the bash
    # path. The child writes PIPESTATUS here, keeping it out of captured output.
    status_read = status_write = None
    pass_fds = ()
    if bash is not None:
        status_read, status_write = os.pipe()
        os.set_blocking(status_read, False)
        pass_fds = (status_write,)
        wrapped = _TRAP_RESET + command + _STATUS_CAPTURE.replace("{fd}", str(status_write))
        argv = [bash, "-o", "pipefail", "-c", wrapped]
    else:
        argv = ["/bin/sh", "-c", command]

    def read_available():
        nonlocal truncated
        # One bounded read per callback lets deadlines run even for commands
        # producing output continuously. Discard overflow without buffering it.
        try:
            chunk = os.read(read_fd, 64 * 1024)
        except BlockingIOError:
            return
        if not chunk:
            loop.remove_reader(read_fd)
            return
        remaining = _OUTPUT_LIMIT - len(output)
        output.extend(chunk[:remaining])
        truncated |= len(chunk) > remaining

    process = None
    spawning = None
    completed = False
    timed_out = False
    pipe_status = None
    try:
        loop.add_reader(read_fd, read_available)
        # Own the pipe separately: Process.wait() must observe the shell's exit,
        # not wait for EOF from a background service that inherited stdout.
        spawning = asyncio.create_task(
            asyncio.create_subprocess_exec(
                *argv,
                cwd=directory,
                stdin=asyncio.subprocess.DEVNULL,
                stdout=write_fd,
                stderr=asyncio.subprocess.STDOUT,
                start_new_session=True,
                pass_fds=pass_fds,
            )
        )
        # Cancellation may arrive after the OS process exists but before its
        # handle is returned. Retain acquisition so finally can stop its group.
        process = await asyncio.shield(spawning)
        os.close(write_fd)
        write_fd = None
        if status_write is not None:
            os.close(status_write)
            status_write = None
        await asyncio.wait_for(process.wait(), timeout=timeout)
        completed = True
    except TimeoutError:
        timed_out = True
    finally:
        try:
            if process is None and spawning is not None:
                process = await spawning
            if process is not None:
                # Successful commands may leave task services running. Their
                # lifetime belongs to the caller or the surrounding environment.
                if not completed:
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                await process.wait()
        finally:
            loop.remove_reader(read_fd)
            # Capture any final pending bytes, then close our pipe even if a
            # detached child still holds stdout. No EOF wait or transport leaks.
            read_available()
            os.close(read_fd)
            if write_fd is not None:
                os.close(write_fd)
            if status_write is not None:
                os.close(status_write)
            if status_read is not None:
                pipe_status = _read_status(status_read)
                os.close(status_read)

    result = {
        "exit_code": process.returncode,
        "output": output.decode("utf-8", errors="replace"),
        "timed_out": timed_out,
        "truncated": truncated,
    }
    # Only surface the stage vector when the executed command actually ended in
    # a pipeline (more than one stage). A single stage already equals exit_code.
    if pipe_status and len(pipe_status) > 1:
        result["pipe_status"] = pipe_status
    return json.dumps(result, ensure_ascii=False)


def _read_status(fd):
    """Drain the child's PIPESTATUS pipe into a list of ints (or None)."""
    chunks = []
    while True:
        try:
            chunk = os.read(fd, 4096)
        except BlockingIOError:
            break
        except OSError:
            break
        if not chunk:
            break
        chunks.append(chunk)
    raw = b"".join(chunks).decode("ascii", errors="replace").strip()
    if not raw:
        return None
    try:
        return [int(part) for part in raw.split()]
    except ValueError:
        return None