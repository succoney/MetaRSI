---
description: Recover and reproduce the grader's exact acceptance contract (per-side normalization, evaluated region, key/address base) before finishing, instead of self-checking against an invented convention. Load when a task compares your output to a reference, names a normalization/parser, a measured region, or example keys/values.
---

# Reproduce the grader's acceptance contract

A locally self-consistent artifact can still score zero when it is built and
self-checked against a convention the grader does not use. Before finishing,
recover the *exact* contract the task supplies and recompute every emitted value
against it. Where the grader's convention is not observable, record the residual
uncertainty instead of adopting a convenient assumption.

## Per-side normalization and comparison basis

- Read how the comparison is defined and reproduce it per side. The grader may
  canonicalize only the *reference* (e.g. re-serializing through a parser) and
  then compare against your raw output, so attribute order, void-tag form and
  entity spelling become differences that were never introduced by your code.
- If the task says your output must be "functionally identical", "unchanged",
  or preserves formatting "except for normalization that may occur during
  parsing", emit the *normalized/canonical* form the task names, not a raw
  byte-preserving copy. A byte-identity self-check will not exercise an
  asymmetric normalization contract.
- If the task names a tool, parser or serialization, run that exact tool on both
  sides of your own check rather than an invented equivalence.

## Evaluated region / tract

- State which substring, tract or feature the grader actually measures, and
  compute the quantity over exactly that region. Do not substitute a nearby
  region your construction happens to produce (e.g. a graded bound evaluated over
  a binding tract plus an adjacent overhang suffix, not just the annealed core).
- When a tolerance or pairwise bound is stated, assert it over the grader's
  region with explicit numbers before declaring success.

## Key / address base and example constants

- Treat example keys, addresses, offsets or values in the prompt as
  *illustrative*, not normative. Derive the value from the actual supplied input
  or the binary's own structure (e.g. its link-time virtual addresses), not from
  the constant shown in the example.
- Verify against a second, freshly produced instance of the input domain (for
  example a recompiled binary) so a base you hard-coded from the example is
  exposed as wrong rather than confirmed.

## Finish with an independent check

- Reload the written artifact from disk and assert the acceptance quantities
  explicitly. Run the task's own command/interface locally from a neutral
  working directory, then state any convention you could not observe.
