"""Input-context compaction middleware (Tree-RSI r2-n5-h0).

Assigned mechanism: bound the model's *input* by compacting stale tool results
and prior-turn reasoning before each primary-model call, instead of only
growing/holding the output budget.

Observed failure mode: on long, tool-heavy tasks the accumulated input context
grows monotonically (extract-elf: ~1.66M prompt tokens over 35 turns) and the
model then spends its whole output budget re-reading/re-deriving facts, ending
turns as empty length-truncated messages with ``reasoning_tokens ==
completion_tokens``. Shrinking the input should reduce that per-turn reasoning
pressure and the frequency of empty turns.

What this hook does (only when the input is over the configured ceiling, so it
is a byte-identical no-op otherwise):

  * Keeps the system prompt, the task question, the running plan (the most
    recent assistant turn) and the last ``keep_recent_results`` tool results
    verbatim.
  * Replaces older tool-result messages with a compact head+tail stub annotated
    with their original size, e.g.
    ``"...[elided 61234 bytes / 480 lines from shell]..."`` -- the tool_call_id
    and role are preserved so assistant/tool pairing stays valid.
  * Elides prior-turn ``reasoning_content`` to a one-line gist, preserving the
    assistant's final content and every tool_call argument.
  * Enforces ``max_input_tokens`` by dropping the *oldest compacted* entries
    first, and never drops the system prompt, the current task text, a tool
    result the most recent assistant turn referenced, or the recent units.

The hook uses only the existing ``before_llm`` lifecycle hook (the workspace
loader already wires it), so no ``runtime/agent.py`` change is needed.

Responses-API runs are intentionally left untouched: on that path the runtime
replays complete output items and only *added* middleware messages reach the
request, so rewriting existing messages would be (mis)read as extra messages
rather than a compaction of the actual input. The evidence tasks for this
hypothesis run through Chat Completions, where the modified message list is the
request, so the mechanism applies there.
"""

from __future__ import annotations

import json
from pathlib import Path

try:  # pragma: no cover - PyYAML is a workspace-loader dependency
    import yaml
except Exception:  # pragma: no cover
    yaml = None

_DEFAULTS = {
    "enabled": True,
    # Number of most-recent tool results kept verbatim.
    "keep_recent_results": 8,
    # Total input-token ceiling. Under this the hook is a byte-identical no-op.
    "max_input_tokens": 48000,
    # Characters kept from the head and the tail of a compacted tool result.
    "stub_chars": 400,
    # Replace prior-turn reasoning with a one-line gist.
    "summarize_reasoning": True,
    # Longest gist (characters) written in place of prior-turn reasoning.
    "gist_chars": 160,
    # Number of most-recent units always kept as context.
    "protect_recent_units": 2,
}

_config_cache: dict[str, dict] = {}

_GIST_PREFIX = "[reasoning gist] "

# Rough characters-per-token estimate; only used for the ceiling decision and
# the trace, never for a hard correctness claim.
_CHARS_PER_TOKEN = 4


# ---------------------------------------------------------------------------
# config
# ---------------------------------------------------------------------------


def _load_config(ctx) -> dict:
    """Read the ``context_compaction`` block from the workspace agent.yaml."""
    cached = None
    root = getattr(getattr(ctx, "workspace", None), "root", None)
    if root is not None and yaml is not None:
        key = str(root)
        cached = _config_cache.get(key)
        if cached is None:
            cached = {}
            try:
                raw = yaml.safe_load(
                    (Path(root) / "agent.yaml").read_text(encoding="utf-8")
                )
                block = (
                    raw.get("context_compaction")
                    if isinstance(raw, dict)
                    else None
                )
                if isinstance(block, dict):
                    cached = {name: block[name] for name in _DEFAULTS if name in block}
            except Exception:
                cached = {}
            _config_cache[key] = cached
    cfg = dict(_DEFAULTS)
    if cached:
        cfg.update(cached)
    return cfg


def _positive_int(value, fallback: int) -> int:
    return value if isinstance(value, int) and value > 0 else fallback


def _nonneg_int(value, fallback: int) -> int:
    return value if isinstance(value, int) and value >= 0 else fallback


# ---------------------------------------------------------------------------
# message helpers
# ---------------------------------------------------------------------------


def _uses_responses_api(ctx) -> bool:
    """Mirror llm.is_openai_model without importing the runtime module."""
    model = getattr(ctx, "model", "") or ""
    m = model.removeprefix("openai/")
    return m.startswith(("gpt-", "o1", "o3", "o4"))


def _content(msg) -> str:
    value = msg.get("content")
    if isinstance(value, str):
        return value
    if value is None:
        return ""
    try:
        return json.dumps(value, ensure_ascii=False)
    except Exception:
        return str(value)


def _reasoning(msg) -> str:
    for key in ("reasoning_content", "reasoning"):
        value = msg.get(key)
        if isinstance(value, str) and value:
            return value
    return ""


def _set_reasoning(msg, text: str) -> None:
    if "reasoning_content" in msg:
        msg["reasoning_content"] = text
        msg.pop("reasoning", None)
    elif "reasoning" in msg:
        msg["reasoning"] = text
    else:
        msg["reasoning_content"] = text


def _msg_tokens(msg) -> int:
    total = 0
    total += len(_content(msg)) // _CHARS_PER_TOKEN
    total += len(_reasoning(msg)) // _CHARS_PER_TOKEN
    tool_calls = msg.get("tool_calls")
    if tool_calls:
        try:
            total += len(json.dumps(tool_calls, ensure_ascii=False)) // _CHARS_PER_TOKEN
        except Exception:
            pass
    return total


def _estimate_tokens(messages: list) -> int:
    return sum(_msg_tokens(m) for m in messages if isinstance(m, dict))


def _stub(content: str, cmd: str, stub_chars: int) -> str:
    """Head+tail stub annotated with the original byte/line counts."""
    if not content:
        return content
    marker = (
        f"\n...[elided {len(content.encode('utf-8', 'replace'))} bytes / "
        f"{content.count(chr(10)) + 1} lines from {cmd or 'tool'}]...\n"
    )
    if len(content) <= stub_chars * 2 + len(marker):
        return content
    head = content[:stub_chars]
    tail = content[-stub_chars:]
    return head + marker + tail


def _gist(reasoning: str, limit: int) -> str:
    text = reasoning.strip()
    if not text:
        return ""
    first = text.splitlines()[0].strip()
    if len(first) > limit:
        first = first[:limit].rstrip() + "\u2026"
    return _GIST_PREFIX + first


def _tool_call_names(messages: list) -> dict:
    """Map tool_call_id -> function name from assistant tool_calls."""
    names: dict[str, str] = {}
    for msg in messages:
        if not isinstance(msg, dict):
            continue
        for tc in msg.get("tool_calls") or []:
            if not isinstance(tc, dict):
                continue
            cid = tc.get("id")
            fn = tc.get("function") or {}
            name = fn.get("name") or tc.get("name") or ""
            if isinstance(cid, str) and cid:
                names[cid] = name or names.get(cid, "tool")
    return names


# ---------------------------------------------------------------------------
# unit grouping (keeps assistant/tool pairing intact when dropping)
# ---------------------------------------------------------------------------


def _build_units(messages: list) -> list[tuple[int, int]]:
    """Group messages into droppable units [start, end).

    An assistant message carrying tool_calls is grouped with *all* immediately
    following tool-result messages, so the pair is always compacted or dropped
    together and the provider never sees a dangling tool call (or tool result).
    """
    units: list[tuple[int, int]] = []
    n = len(messages)
    i = 0
    while i < n:
        msg = messages[i]
        role = msg.get("role") if isinstance(msg, dict) else None
        if role == "assistant" and isinstance(msg, dict) and msg.get("tool_calls"):
            j = i + 1
            while j < n and isinstance(messages[j], dict) and messages[j].get("role") == "tool":
                j += 1
            units.append((i, j))
            i = j
        else:
            units.append((i, i + 1))
            i += 1
    return units


def _protected_indices(messages: list, kept_tool: set, cfg: dict, ctx) -> set:
    protected: set[int] = set()
    question = getattr(ctx, "question", "") or ""
    first_user_seen = False
    last_assistant = -1
    for i, msg in enumerate(messages):
        if not isinstance(msg, dict):
            continue
        role = msg.get("role")
        if role == "system":
            protected.add(i)
        elif role == "user":
            content = _content(msg)
            if not first_user_seen:
                protected.add(i)
                first_user_seen = True
            elif question and content.strip() == question.strip():
                protected.add(i)
        elif role == "assistant":
            last_assistant = i
    if last_assistant >= 0:
        protected.add(last_assistant)
    protected |= set(kept_tool)

    # Keep the most-recent units verbatim.
    units = _build_units(messages)
    for start, end in units[-_nonneg_int(cfg.get("protect_recent_units"), _DEFAULTS["protect_recent_units"]):]:
        protected.update(range(start, end))
    return protected


# ---------------------------------------------------------------------------
# compaction
# ---------------------------------------------------------------------------


def _compact(messages: list, cfg: dict, ctx) -> tuple[list, int, int]:
    keep = _nonneg_int(cfg.get("keep_recent_results"), _DEFAULTS["keep_recent_results"])
    stub_chars = _positive_int(cfg.get("stub_chars"), _DEFAULTS["stub_chars"])
    summarize = bool(cfg.get("summarize_reasoning", True))
    gist_chars = _positive_int(cfg.get("gist_chars"), _DEFAULTS["gist_chars"])

    names = _tool_call_names(messages)

    tool_indices = [
        i for i, m in enumerate(messages)
        if isinstance(m, dict) and m.get("role") == "tool"
    ]
    kept_tool = set(tool_indices[-keep:]) if keep > 0 else set()

    last_assistant = -1
    for i, m in enumerate(messages):
        if isinstance(m, dict) and m.get("role") == "assistant":
            last_assistant = i

    out: list = []
    results_compacted = 0
    reasoning_elided = 0
    for i, msg in enumerate(messages):
        if not isinstance(msg, dict):
            out.append(msg)
            continue
        role = msg.get("role")
        if role == "tool" and i not in kept_tool:
            original = _content(msg)
            cid = msg.get("tool_call_id")
            cmd = names.get(cid, "tool") if isinstance(cid, str) else "tool"
            stub = _stub(original, cmd, stub_chars)
            if stub != original:
                new_msg = dict(msg)
                new_msg["content"] = stub
                out.append(new_msg)
                results_compacted += 1
                continue
        if role == "assistant" and summarize and i != last_assistant:
            reasoning = _reasoning(msg)
            if reasoning and len(reasoning) > gist_chars:
                new_msg = dict(msg)
                _set_reasoning(new_msg, _gist(reasoning, gist_chars))
                out.append(new_msg)
                reasoning_elided += 1
                continue
        out.append(msg)
    return out, results_compacted, reasoning_elided


def _enforce_ceiling(messages: list, max_tokens: int, cfg: dict, ctx) -> tuple[list, int]:
    """Drop the oldest compacted (unprotected) units until under the ceiling."""
    if _estimate_tokens(messages) <= max_tokens:
        return messages, 0

    units = _build_units(messages)
    tool_indices = [
        i for i, m in enumerate(messages)
        if isinstance(m, dict) and m.get("role") == "tool"
    ]
    keep = _nonneg_int(cfg.get("keep_recent_results"), _DEFAULTS["keep_recent_results"])
    kept_tool = set(tool_indices[-keep:]) if keep > 0 else set()
    protected = _protected_indices(messages, kept_tool, cfg, ctx)

    # Mark units protected; also protect any unit that is a lone tool message so
    # we never orphan a result from the assistant turn that produced it.
    unit_info: list[tuple[tuple[int, int], bool]] = []
    for start, end in units:
        is_protected = any(idx in protected for idx in range(start, end))
        if end - start == 1 and isinstance(messages[start], dict) and messages[start].get("role") == "tool":
            is_protected = True
        unit_info.append(((start, end), is_protected))

    dropped = 0
    remaining = list(unit_info)
    while _estimate_tokens([m for (s, e), _ in remaining for m in messages[s:e]]) > max_tokens:
        # find oldest unprotected unit
        idx_to_drop = next(
            (k for k, (_, prot) in enumerate(remaining) if not prot), None
        )
        if idx_to_drop is None:
            break
        remaining.pop(idx_to_drop)
        dropped += 1

    if dropped == 0:
        return messages, 0
    result: list = []
    for (s, e), _ in remaining:
        result.extend(messages[s:e])
    return result, dropped


# ---------------------------------------------------------------------------
# hook
# ---------------------------------------------------------------------------


async def before_llm(messages, ctx):
    try:
        cfg = _load_config(ctx)
        if not cfg.get("enabled", True) or not isinstance(messages, list):
            return messages
        if len(messages) < 3:
            return messages

        # Responses-API runs replay the conversation from response_history and
        # only *added* before_llm messages reach the request; rewriting existing
        # messages there would inject duplicates instead of compacting. Leave
        # them untouched.
        if _uses_responses_api(ctx):
            ctx.trace.event(
                "context_compaction_skipped",
                turn=getattr(ctx, "turn", 0),
                reason="responses_api",
            )
            return messages

        max_tokens = _positive_int(
            cfg.get("max_input_tokens"), _DEFAULTS["max_input_tokens"]
        )
        tokens_before = _estimate_tokens(messages)

        # Byte-identical no-op while the input is within the ceiling.
        if tokens_before <= max_tokens:
            return messages

        # First pass: keep up to keep_recent_results verbatim and drop the
        # oldest compacted units. If even that is still over the ceiling (the
        # recent verbatim results alone are very large), progressively keep
        # fewer verbatim results -- still never stubbing the result the most
        # recent assistant turn referenced (see unit protection above).
        base_keep = _nonneg_int(
            cfg.get("keep_recent_results"), _DEFAULTS["keep_recent_results"]
        )
        keep = base_keep
        compacted = messages
        results_compacted = reasoning_elided = dropped = 0
        while True:
            pass_cfg = dict(cfg)
            pass_cfg["keep_recent_results"] = keep
            compacted, results_compacted, reasoning_elided = _compact(
                messages, pass_cfg, ctx
            )
            compacted, dropped = _enforce_ceiling(
                compacted, max_tokens, pass_cfg, ctx
            )
            if _estimate_tokens(compacted) <= max_tokens or keep <= 1:
                break
            keep = max(1, keep // 2)

        tokens_after = _estimate_tokens(compacted)

        ctx.trace.event(
            "context_compaction",
            turn=getattr(ctx, "turn", 0),
            tokens_before=tokens_before,
            tokens_after=tokens_after,
            results_compacted=results_compacted,
            reasoning_elided=reasoning_elided,
            units_dropped=dropped,
            keep_recent_results=keep,
            ceiling=max_tokens,
        )
        return compacted
    except Exception as e:  # a compaction failure must never break the run
        try:
            ctx.trace.event("context_compaction_error", error=str(e))
        except Exception:
            pass
        return messages