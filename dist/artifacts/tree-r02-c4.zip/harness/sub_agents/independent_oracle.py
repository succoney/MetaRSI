"""Independent-oracle authenticator subagent.

The runtime invokes this module immediately before an answer is finalized
(see ``runtime/agent.py:_run_independent_oracle``). It is handed the task
question plus the produced artifact and is asked -- in a fresh, isolated
context that contains none of the main agent's conversation or assumptions --
to independently reproduce each quantity the artifact claims, using a method
that does *not* reuse the artifact's own self-test, definition or delivery
path. It may request external shell commands, which are executed in their own
process group so that a *real* signal (e.g. SIGINT to the subprocess, as a
grader would deliver it) reaches the child rather than an in-process
``os.kill`` on the parent. It returns a structured agree/disagree verdict that
the harness enforces.

Design notes (to keep the check genuinely independent):
  * the prompt is built only from the question + artifact + an optional list
    of claimed values; no prior transcript is replayed;
  * a different model connection (the side model) is used via ``ctx.side_text``;
  * the subagent can only read/execute, it never edits the artifact itself;
  * an inconclusive verdict (``agree: null``) never blocks finalization.
"""

from __future__ import annotations

import asyncio
import json
import os
import signal
from pathlib import Path

DEFAULT_CONFIG = {
    "enabled": True,
    "max_checks": 3,
    "require_agreement": True,
    "max_steps": 2,
    "command_timeout": 30,
}

_INSTRUCTIONS = (
    "You are an INDEPENDENT AUTHENTICATOR. You did not write the artifact and "
    "must not trust its self-tests, its declared definitions, or its delivery "
    "path. For every quantity the artifact asserts, recompute it from the raw "
    "inputs using a DIFFERENT method or environment than the artifact used, "
    "then compare your value against the artifact's claim. Penalise the "
    "artifact when its own check reproduced its own assumption (e.g. an "
    "in-process signal instead of an external one, or a truncated window "
    "instead of the full tract). You may run shell commands to gather evidence."
)


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


def canonical_reserialize(text: str) -> str:
    """Re-serialize ``text`` canonically so cosmetic differences do not hide
    real ones: JSON is re-emitted with sorted keys, otherwise line endings are
    normalised and surrounding whitespace stripped."""
    if not isinstance(text, str):
        text = str(text)
    try:
        return json.dumps(json.loads(text), sort_keys=True, ensure_ascii=False)
    except Exception:
        return text.replace("\r\n", "\n").replace("\r", "\n").strip()


def _parse_json_object(text) -> dict | None:
    """Extract the first JSON object from a model reply, tolerating prose."""
    if isinstance(text, dict):
        return text
    if not isinstance(text, str):
        return None
    candidate = text.strip()
    try:
        value = json.loads(candidate)
        return value if isinstance(value, dict) else None
    except Exception:
        pass
    start, end = candidate.find("{"), candidate.rfind("}")
    if start != -1 and end > start:
        try:
            value = json.loads(candidate[start : end + 1])
            return value if isinstance(value, dict) else None
        except Exception:
            return None
    return None


async def _run_external_command(command: str, cwd, timeout: float) -> dict:
    """Run ``command`` in its own process group and capture combined output.

    Start-new-session plus ``os.killpg`` is what allows a caller to deliver a
    genuine external signal to the whole child group, mirroring how a grader
    drives the program as a subprocess, instead of an in-process kill that
    cannot reach it.
    """
    if not isinstance(command, str) or not command.strip():
        return {"exit_code": None, "output": "", "error": "empty command"}
    try:
        proc = await asyncio.create_subprocess_exec(
            "/bin/sh",
            "-c",
            command,
            cwd=str(cwd),
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
            start_new_session=True,
        )
    except Exception as e:  # pragma: no cover - environment dependent
        return {"exit_code": None, "output": "", "error": str(e)}
    timed_out = False
    out = b""
    try:
        out, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        timed_out = True
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except (ProcessLookupError, PermissionError):
            pass
        try:
            out, _ = await proc.communicate()
        except Exception:
            out = b""
    return {
        "exit_code": proc.returncode,
        "output": (out or b"").decode("utf-8", errors="replace")[:8000],
        "timed_out": timed_out,
    }


def _load_config(workspace_root) -> dict:
    """Read the ``independent_oracle`` block from agent.yaml (defaults applied)."""
    cfg = dict(DEFAULT_CONFIG)
    try:
        import yaml

        data = yaml.safe_load(
            (Path(workspace_root) / "agent.yaml").read_text(encoding="utf-8")
        ) or {}
        block = data.get("independent_oracle")
        if isinstance(block, dict):
            cfg.update(block)
    except Exception:
        pass
    return cfg


def _build_prompt(question: str, artifact: str, claimed: str, transcript: str) -> str:
    lines = [
        _INSTRUCTIONS,
        "",
        "=== TASK QUESTION ===",
        question or "(not provided)",
        "",
        "=== ARTIFACT UNDER CHECK ===",
        artifact or "(empty)",
    ]
    if claimed:
        lines += ["", "=== VALUES THE ARTIFACT CLAIMS ===", claimed]
    lines += [
        "",
        "=== YOUR INDEPENDENT TRANSCRIPT SO FAR ===",
        transcript or "(none)",
        "",
        "Reply with exactly ONE JSON object and no prose:",
        '  {"action":"run","command":"<shell command to gather independent evidence>"}',
        "or, once you can decide:",
        '  {"action":"verdict","agree":true|false|null,"independent_values":<any>,'
        '"counter_evidence":"<what differs and why>","method":"<how you recomputed>"}',
        "Use agree=false ONLY when your independent recomputation contradicts "
        "the artifact. Use agree=null when you cannot independently check it.",
    ]
    return "\n".join(lines)


def _normalise_payload(input) -> dict:
    if isinstance(input, dict):
        return input
    if isinstance(input, str):
        try:
            value = json.loads(input)
            if isinstance(value, dict):
                return value
        except Exception:
            pass
        return {"artifact": input}
    return {"artifact": "" if input is None else str(input)}


# ---------------------------------------------------------------------------
# entry point (workspace subagent API: run(input, ctx) -> str)
# ---------------------------------------------------------------------------


async def run(input, ctx) -> str:
    payload = _normalise_payload(input)
    cfg = dict(DEFAULT_CONFIG)
    config = payload.get("config")
    if isinstance(config, dict):
        cfg.update(config)
    cfg.update(_load_config(getattr(ctx.workspace, "root", ".")))

    if not cfg.get("enabled", True):
        return json.dumps(
            {"agree": None, "block": False, "reason": "independent_oracle disabled"}
        )

    # Per-run check budget, tracked on the shared context.
    store = ctx.state["independent_oracle"]
    checks = int(store.get("checks", 0))
    max_checks = int(cfg.get("max_checks", 3))
    if checks >= max_checks:
        return json.dumps(
            {"agree": None, "block": False, "reason": "max_checks reached"}
        )
    store["checks"] = checks + 1

    question = str(payload.get("question") or getattr(ctx, "question", "") or "")
    artifact = str(payload.get("artifact") or "")
    claimed = str(payload.get("claimed") or "")
    max_steps = max(1, int(cfg.get("max_steps", 2)))
    timeout = float(cfg.get("command_timeout", 30))
    require_agreement = bool(cfg.get("require_agreement", True))

    transcript_parts: list[str] = []
    verdict: dict = {"agree": None, "reason": "no verdict produced"}
    for _step in range(max_steps):
        prompt = _build_prompt(
            question, artifact, claimed, "\n".join(transcript_parts)
        )
        reply = await ctx.side_text(
            prompt, purpose="independent_oracle", max_tokens=500
        )
        if not reply:
            verdict = {"agree": None, "reason": "oracle produced no response"}
            break
        parsed = _parse_json_object(reply)
        if parsed is None:
            verdict = {
                "agree": None,
                "reason": "unparseable oracle reply",
                "raw": reply[:500],
            }
            break
        if parsed.get("action") == "run" and parsed.get("command"):
            result = await _run_external_command(
                str(parsed["command"]), ctx.working_dir, timeout
            )
            transcript_parts.append(
                "$ " + str(parsed["command"]) + "\n" + canonical_reserialize(
                    json.dumps(result, ensure_ascii=False)
                )
            )
            continue
        # Treat anything else as the verdict.
        verdict = {
            "agree": parsed.get("agree"),
            "claimed": parsed.get("claimed", claimed),
            "independent_values": parsed.get("independent_values"),
            "counter_evidence": parsed.get("counter_evidence")
            or parsed.get("reason")
            or "",
            "method": parsed.get("method") or "",
        }
        break

    disagree = verdict.get("agree") is False
    verdict["block"] = bool(disagree and require_agreement)
    return json.dumps(verdict, ensure_ascii=False, default=str)