"""Expectation-reconciliation gate middleware (Tree-RSI r1-n0-h0).

Observed failure mode (input-interpretation rationalization): the agent commits
a numeric interpretation (writes a results JSON, prints a fit log, sets a script
constant) that contradicts an expected / canonical quantity the task states, and
then rationalizes the mismatch instead of re-deriving the input parsing.
raman-fitting is the motivating trace: it committed ``G fit x0=10439.54`` on the
file x-axis while the canonical graphene G band sits near ~1580.

This middleware implements an expectation-reconciliation gate using only the
existing ``before_llm`` / ``before_final`` hooks:

  * Parse expected / canonical numeric values that the task text states (lines
    carrying expectation cues such as "expected", "should be", "canonical",
    "around", "~") plus, optionally, values from declared reference files, into
    ``ctx.state["expectation_gate"]["expected"]``.
  * On each turn, extract the numbers the agent has *committed* from recent tool
    results / arguments (written JSON, printed fit logs, script constants) and
    pair them with expected entries by a normalized quantity name.
  * If a paired value disagrees beyond a configurable tolerance, inject a
    directive telling the agent to re-derive the input parsing (column order,
    units, axis transform) rather than relabel, and (``before_final`` ->
    ``action=continue``) refuse finalization while the conflict is unresolved.

It reasons only about the *shape* of stated requirements (quantity names,
numbers, tolerance) and never about any particular task's answer. On tasks that
state no expected numeric values it is a no-op: the gate stays empty and the
hooks return the messages unchanged / ``None``.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

try:  # pragma: no cover - PyYAML is a workspace-loader dependency
    import yaml
except Exception:  # pragma: no cover
    yaml = None

_STATE_KEY = "expectation_gate"
_PREFIX = "[expectation-gate]"

_DEFAULTS = {
    "enabled": True,
    # Relative tolerance: |got-exp| / max(|exp|,|got|) must be <= this.
    "rel_tolerance": 0.05,
    # Absolute tolerance floor (same units as the values); 0 disables it.
    "abs_tolerance": 0.0,
    # Per-source cap on parsed entries.
    "max_checks": 40,
    # Look back this many turns for committed values.
    "window": 8,
    # Per-run cap on injected re-derivation directives.
    "max_injections": 2,
    # Per-run cap on before_final "continue" blocks.
    "max_final_blocks": 1,
    # Extra regexes marking an expectation-bearing fragment.
    "expected_patterns": [],
    # Optional reference files whose numeric content is treated as expected.
    "expected_reference_files": [],
}

# A quantity-name/quantity-value pair, e.g. ``x0=10439.54``, ``"gamma": 9.06``,
# ``G fit x0=10439.54``. The optional quotes allow JSON payloads.
_KV_RE = re.compile(
    r"""(?<![\w.])['"]?([A-Za-z_][A-Za-z0-9_]{0,40})['"]?\s*[:=~]\s*"""
    r"""([-+]?\d{1,}(?:[.,]\d+)?(?:[eE][-+]?\d+)?)"""
)

# A bare number, used only inside expectation-bearing fragments.
_NUM_RE = re.compile(
    r"(?<![\w.])[-+]?\d{1,}(?:[.,]\d+)?(?:[eE][-+]?\d+)?(?!\w)"
)

# Fragments that state an expectation rather than an observation.
_CUE_RE = re.compile(
    r"\b(?:expect\w*|should|must|canonical|nominal|target|around|approx\w*|"
    r"approximately|near|equals?|equal\s+to|exact(?:ly)?)\b|~",
    re.IGNORECASE,
)

_CUE_WORDS = {
    "expected",
    "expect",
    "expects",
    "should",
    "must",
    "be",
    "is",
    "are",
    "was",
    "were",
    "canonical",
    "nominal",
    "target",
    "around",
    "approx",
    "approximately",
    "near",
    "equal",
    "equals",
    "exactly",
    "exact",
}

# Generic words that should never become a quantity key.
_KEY_STOP = _CUE_WORDS | {
    "the",
    "a",
    "an",
    "of",
    "and",
    "or",
    "to",
    "in",
    "on",
    "at",
    "for",
    "with",
    "value",
    "values",
    "result",
    "results",
    "output",
    "given",
    "file",
    "use",
}

_config_cache: dict[str, dict] = {}


def _state(ctx) -> dict:
    """Return the gate's per-run state dict (robust to plain dicts)."""
    try:
        return ctx.state.setdefault(_STATE_KEY, {})
    except AttributeError:
        ctx.state[_STATE_KEY] = {}
        return ctx.state[_STATE_KEY]


# ---------------------------------------------------------------------------
# config / helpers
# ---------------------------------------------------------------------------


def _load_config(ctx) -> dict:
    """Read the ``expectation_gate`` block from the workspace agent.yaml."""
    cfg = dict(_DEFAULTS)
    root = getattr(getattr(ctx, "workspace", None), "root", None)
    if root is not None and yaml is not None:
        key = str(root)
        cached = _config_cache.get(key)
        if cached is None:
            cached = {}
            try:
                raw = yaml.safe_load(
                    (Path(root) / "agent.yaml").read_text(encoding="utf-8")
                )
                block = raw.get("expectation_gate") if isinstance(raw, dict) else None
                if isinstance(block, dict):
                    cached = {k: block[k] for k in _DEFAULTS if k in block}
            except Exception:
                cached = {}
            _config_cache[key] = cached
        cfg.update(cached)
    return cfg


def _cfg_float(cfg: dict, name: str) -> float:
    value = cfg.get(name)
    if isinstance(value, bool):
        return float(_DEFAULTS[name])
    if isinstance(value, (int, float)):
        return float(value)
    return float(_DEFAULTS[name])


def _cfg_int(cfg: dict, name: str, *, minimum: int = 0) -> int:
    value = cfg.get(name)
    if isinstance(value, bool) or not isinstance(value, int):
        return int(_DEFAULTS[name])
    return value if value >= minimum else int(_DEFAULTS[name])


def _num(raw) -> float | None:
    if raw is None:
        return None
    text = str(raw).strip()
    if not text:
        return None
    if "," in text and "." in text:
        text = text.replace(",", "")
    elif "," in text:
        text = text.replace(",", ".")
    try:
        return float(text)
    except ValueError:
        return None


def _norm_key(raw: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", (raw or "").lower()).strip("_")


def _fragments(text: str) -> list[str]:
    out: list[str] = []
    for line in (text or "").splitlines():
        line = line.strip()
        if not line:
            continue
        parts = re.split(r"(?<=[.;:])\s+(?=[A-Z0-9/])", line) or [line]
        out.extend(parts if parts else [line])
    return out


def _within(expected: float, got: float, rel: float, abs_tol: float) -> bool:
    diff = abs(got - expected)
    if abs_tol > 0 and diff <= abs_tol:
        return True
    denom = max(abs(expected), abs(got), 1e-12)
    return diff / denom <= rel


def _add(entries: list, seen: set, key: str, value: float, text: str, cap: int):
    if not key or key in _KEY_STOP or len(key) < 1:
        return
    sig = (key, round(value, 9))
    if sig in seen:
        return
    seen.add(sig)
    entries.append({"key": key, "value": value, "text": text[:200]})
    if len(entries) >= cap:
        return


# ---------------------------------------------------------------------------
# expected-value extraction
# ---------------------------------------------------------------------------


def _expected_entries(question: str, cfg: dict) -> list[dict]:
    patterns = [
        re.compile(p, re.IGNORECASE)
        for p in (cfg.get("expected_patterns") or [])
        if isinstance(p, str) and p
    ]
    cap = _cfg_int(cfg, "max_checks", minimum=1)
    entries: list[dict] = []
    seen: set = set()
    for frag in _fragments(question):
        if not (_CUE_RE.search(frag) or any(p.search(frag) for p in patterns)):
            continue
        # Keyed values (name[:=~]number) are the strongest signal.
        masked = frag
        for match in _KV_RE.finditer(frag):
            key = _norm_key(match.group(1))
            value = _num(match.group(2))
            if value is not None:
                _add(entries, seen, key, value, frag, cap)
            masked = masked[: match.start()] + " " * (match.end() - match.start()) + masked[match.end():]
        # Unkeyed numbers in a cue fragment take their nearest preceding
        # significant word as the name (single token, no digits inside it).
        for match in _NUM_RE.finditer(masked):
            value = _num(match.group(0))
            if value is None:
                continue
            tail = re.split(r"[;:!?()\[\]{}]", masked[: match.start()])[-1]
            toks = [
                t
                for t in re.findall(r"[A-Za-z][A-Za-z0-9]*", tail)
                if t.lower() not in _KEY_STOP and not any(c.isdigit() for c in t)
            ]
            if not toks:
                continue
            key = _norm_key(toks[-1])
            _add(entries, seen, key, value, frag, cap)
        if len(entries) >= cap:
            break
    return entries


def _expected_from_files(ctx, cfg: dict) -> list[dict]:
    paths = cfg.get("expected_reference_files")
    if not isinstance(paths, list) or not paths:
        return []
    base = Path(getattr(ctx, "working_dir", None) or Path.cwd())
    cap = _cfg_int(cfg, "max_checks", minimum=1)
    entries: list[dict] = []
    seen: set = set()
    for token in paths:
        if not isinstance(token, str) or not token:
            continue
        path = Path(token)
        if not path.is_absolute():
            path = base / path
        try:
            if not path.is_file():
                continue
            text = path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        for key, val in _KV_RE.findall(text):
            value = _num(val)
            if value is not None:
                _add(entries, seen, _norm_key(key), value, text, cap)
        if len(entries) >= cap:
            break
    return entries


# ---------------------------------------------------------------------------
# committed-value extraction
# ---------------------------------------------------------------------------


def _committed_entries(ctx, cfg: dict, extra_texts: list | None = None) -> list[dict]:
    window = _cfg_int(cfg, "window", minimum=1)
    lo = getattr(ctx, "turn", 0) - window
    texts: list[str] = []
    for rec in getattr(ctx, "tool_history", None) or []:
        turn = getattr(rec, "turn", 0)
        if turn < lo or turn >= getattr(ctx, "turn", 0):
            continue
        texts.append(getattr(rec, "result_preview", "") or "")
        try:
            texts.append(
                json.dumps(getattr(rec, "executed_args", {}) or {}, ensure_ascii=False)
            )
        except Exception:
            pass
    for extra in extra_texts or []:
        if isinstance(extra, str):
            texts.append(extra)

    entries: list[dict] = []
    index: dict[str, int] = {}
    for text in texts:
        for key, val in _KV_RE.findall(text):
            name = _norm_key(key)
            value = _num(val)
            if value is None or not name or name in _KEY_STOP:
                continue
            if name in index:
                entries[index[name]] = {"key": name, "value": value}
            else:
                index[name] = len(entries)
                entries.append({"key": name, "value": value})
    return entries


def _find_conflicts(expected: list[dict], committed: list[dict], cfg: dict) -> list[dict]:
    rel = _cfg_float(cfg, "rel_tolerance")
    abs_tol = _cfg_float(cfg, "abs_tolerance")
    by_key: dict[str, list[float]] = {}
    for entry in committed:
        by_key.setdefault(entry["key"], []).append(entry["value"])
    conflicts: list[dict] = []
    for entry in expected:
        for value in by_key.get(entry["key"], []):
            if not _within(entry["value"], value, rel, abs_tol):
                conflicts.append(
                    {
                        "key": entry["key"],
                        "expected": entry["value"],
                        "committed": value,
                    }
                )
    return conflicts


def _conflict_directive(conflicts: list[dict], *, final: bool) -> str:
    lines = [
        f"- '{c['key']}': expected ~{c['expected']:g}, committed {c['committed']:g}"
        for c in conflicts[:5]
    ]
    head = (
        f"{_PREFIX} A value you committed contradicts a value the task states as "
        "expected/canonical. Do NOT relabel or rationalize it."
    )
    body = (
        " Re-derive the input interpretation from scratch -- re-check the column "
        "order, the units, and any axis transform (e.g. wavelength<->shift "
        "conversion) rather than renaming features -- and reconcile it with the "
        "expected value within tolerance."
    )
    tail = (
        " Fix the artifact before submitting your final answer."
        if final
        else " Address this before continuing."
    )
    return f"{head}\n" + "\n".join(lines) + body + tail


# ---------------------------------------------------------------------------
# hooks
# ---------------------------------------------------------------------------


async def before_llm(messages, ctx):
    """Detect expectation conflicts and inject a re-derivation directive."""
    try:
        cfg = _load_config(ctx)
        if not cfg.get("enabled", True):
            return messages

        state = _state(ctx)
        if "expected" not in state:
            expected = _expected_entries(getattr(ctx, "question", "") or "", cfg)
            expected.extend(_expected_from_files(ctx, cfg))
            state["expected"] = expected
            ctx.trace.event("expectation_gate_expected", count=len(expected))

        expected = state.get("expected") or []
        if not expected:
            return messages

        committed = _committed_entries(ctx, cfg)
        conflicts = _find_conflicts(expected, committed, cfg)

        max_injections = _cfg_int(cfg, "max_injections", minimum=0)
        injections = state.get("injections", 0)
        if not isinstance(injections, int):
            injections = 0

        if not conflicts:
            state["unresolved"] = 0
            return messages

        state["unresolved"] = len(conflicts)
        ctx.trace.event(
            "expectation_gate_conflict",
            turn=getattr(ctx, "turn", 0),
            count=len(conflicts),
            keys=[c["key"] for c in conflicts[:5]],
        )

        if injections >= max_injections:
            return messages
        if state.get("last_inject_turn") == getattr(ctx, "turn", 0):
            return messages
        if getattr(ctx, "remaining_turns", 1) <= 0:
            return messages

        state["injections"] = injections + 1
        state["last_inject_turn"] = getattr(ctx, "turn", 0)
        ctx.trace.event(
            "expectation_gate_directive",
            turn=getattr(ctx, "turn", 0),
            count=len(conflicts),
            injections=injections + 1,
        )
        directive = _conflict_directive(conflicts, final=False)
        if isinstance(messages, list):
            return messages + [{"role": "user", "content": directive}]
        return messages
    except Exception as e:  # never break the run on a gate failure
        try:
            ctx.trace.event("expectation_gate_error", hook="before_llm", error=str(e))
        except Exception:
            pass
        return messages


async def before_final(answer, ctx):
    """Refuse finalization while an expectation conflict is unresolved."""
    try:
        cfg = _load_config(ctx)
        if not cfg.get("enabled", True):
            return None

        expected = (ctx.state.get(_STATE_KEY) or {}).get("expected")
        if not expected:
            return None

        # Include the candidate answer text so a value stated only in the final
        # answer is still reconciled.
        committed = _committed_entries(
            ctx, cfg, extra_texts=[answer if isinstance(answer, str) else ""]
        )
        conflicts = _find_conflicts(expected, committed, cfg)
        if not conflicts:
            return None

        state = _state(ctx)
        max_blocks = _cfg_int(cfg, "max_final_blocks", minimum=0)
        blocks = state.get("final_blocks", 0)
        if not isinstance(blocks, int):
            blocks = 0
        if blocks >= max_blocks:
            return None
        state["final_blocks"] = blocks + 1
        ctx.trace.event(
            "expectation_gate_final_block",
            count=len(conflicts),
            keys=[c["key"] for c in conflicts[:5]],
        )
        return {
            "action": "continue",
            "feedback": _conflict_directive(conflicts, final=True),
        }
    except Exception as e:
        try:
            ctx.trace.event("expectation_gate_error", hook="before_final", error=str(e))
        except Exception:
            pass
        return None