#!/bin/sh
# PostToolUse(Bash) output plumbing.
#
# Scope: silent for ordinary Bash results. It speaks only when the result
# itself reports that the command was cut short by the harness - the structured
# interrupt flag, the Bash tool's own timeout notice, or the harness's
# output-token-limit notice - which is the observable edge of the
# budget-exhaustion failure cluster: a run that ends with the graded artifact
# unwritten because a long step was re-issued instead of being converted into a
# bounded, state-persisting one.
#
# Deliberately narrow: it does NOT match bare command-output tokens such as
# "Killed" or "exit code 124", which occur routinely inside ordinary,
# successfully-returned output (a log tail, a grep over build logs, OOM
# messages, a failed test). Those produced the note on steps that were not cut
# short, so only harness-generated cut-off signals are accepted here.
#
# Deliberately non-blocking: it never denies a command, because the measured
# PreToolUse denial candidates regressed tasks whose commands were legitimate.
# It only adds one short action line at the moment the cut-off is observed.
#
# Bounded by construction: reads stdin once, one grep, no loops, no writes,
# no network. Fails open (no match -> exit 0 with no output).
input=$(cat 2>/dev/null)

printf '%s' "$input" | grep -Eq '"interrupted"[[:space:]]*:[[:space:]]*true|Command timed out|Output token limit hit' || exit 0

printf '%s' '{"hookSpecificOutput":{"hookEventName":"PostToolUse","additionalContext":"HARNESS (tool step cut short): the previous command did not complete - the harness reported it as interrupted or timed out. Before re-issuing it, persist whatever partial state it produced to disk (write the partial artifact or its log to a file), then re-enter the remaining work as a shorter step with an explicit timeout, or run it with run_in_background and check its real interface with one short bounded command. Do not repeat the same long command unchanged, and do not end the turn while a background job must finish for the statement-named artifact to exist."}}'