#!/bin/sh
# SessionStart(compact) carryover for the Claude Code harness.
#
# Why this shape: the dilated always-on checklist (SessionStart with no matcher,
# plus PostToolUse on Bash|Write|Edit) re-stated prose on every tool call and
# measured as a regression. This fires ONLY when a session resumes from a
# compacted context, i.e. at the one moment where summary loss is real, so it
# cannot dilute the per-turn context. It carries over a FACT read from the
# transcript (the artifact paths actually written this session), not a restated
# rule, and names the single closing action.
#
# Bounded by construction: reads stdin once, one grep/sed pipeline over the
# transcript file, no network, no writes. Fails open (any missing input -> no
# output, exit 0, so the session starts unchanged).
input=$(cat 2>/dev/null)

# transcript_path arrives in the hook payload; without it there is nothing to
# read, so stay silent.
tp=$(printf '%s' "$input" | sed -n 's/.*"transcript_path"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p')
[ -z "$tp" ] && exit 0
[ -r "$tp" ] || exit 0

# Artifacts persisted so far = distinct paths that are the file_path of a
# Write/Edit tool_use. The tool name is required to match, because Read (and
# Grep/Glob) carry the same "file_path" key for files that were only opened;
# counting those would present read-only references as persisted deliverables.
# A matched fragment is the tool_use's own name+input pair, so a Read on the
# same transcript line cannot contribute. Capped at 8 to keep the block small.
paths=$(grep -oE '"name"[[:space:]]*:[[:space:]]*"(Write|Edit|MultiEdit)"[[:space:]]*,[[:space:]]*"input"[[:space:]]*:[[:space:]]*\{[[:space:]]*"file_path"[[:space:]]*:[[:space:]]*"[^"]*"' "$tp" 2>/dev/null \
        | sed -n 's/.*"file_path"[[:space:]]*:[[:space:]]*"\([^"]*\)"/\1/p' \
        | sort -u | head -n 8 | tr '\n' ' ')
paths=$(printf '%s' "$paths" | sed 's/[[:space:]]*$//')

if [ -n "$paths" ]; then
  body="artifacts already written this session (Write/Edit targets): $paths . Re-read those files from disk before continuing; do not re-derive them from the summary."
else
  body="no artifact write is recorded in this session's transcript yet, so if the statement names a deliverable path and that file does not exist, creating it is the next action."
fi

msg="HARNESS CONTEXT CARRYOVER (state summarized by compaction is gone): $body Closing requirement for this task: run the statement's literal acceptance command from a fresh process against the artifact as it exists on disk, and assert the exact keyspace, structural grammar, unit/scale convention and (for 'all valid answers') set equality that the statement names. A check that only validates your own assumptions is not acceptance."

# Escape for embedding in a JSON string (paths may contain backslashes).
esc=$(printf '%s' "$msg" | sed 's/\\/\\\\/g; s/"/\\"/g')

printf '{"hookSpecificOutput":{"hookEventName":"SessionStart","additionalContext":"%s"}}' "$esc"