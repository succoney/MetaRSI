"""Spec-ledger memory middleware.

Observed failure mode (requirement drift / omission): the task text states
checked requirements (physical units, normalization / format-preservation
phrases, structural preconditions such as "at least N before the ... site",
and declared output paths), the agent's own reasoning often names them, yet the
authored artifact silently drops them or swaps in a convenient reading.

This middleware keeps the task's *own* stated requirements in the agent's
persistent state (a "spec ledger") and re-surfaces a compact digest while the
deliverable is being authored and immediately before finalization. It is a
memory re-anchoring mechanism: it encodes nothing the task did not already say
and reasons only about the question text plus turn counts, never about task
content specifics.

Hooks used (all supplied by the existing workspace loader; no runtime change):
  * before_llm  - parse the question once (recon turn) into ctx.state, and
                  re-inject the ledger digest every `remind_interval_turns`.
  * before_final - once, ask the agent to confirm each ledger entry before it
                  submits its final answer.

It is a no-op on tasks whose text yields no requirement-bearing lines, so the
ledger stays empty and behavior is byte-identical to the parent there.
"""

from __future__ import annotations

import re
from pathlib import Path

try:  # pragma: no cover - PyYAML is a workspace-loader dependency
    import yaml
except Exception:  # pragma: no cover
    yaml = None

_LEDGER_PREFIX = "[spec-ledger reminder]"

_DEFAULTS = {
    "enabled": True,
    # Re-inject the digest every N turns (0 disables periodic reminders).
    "remind_interval_turns": 6,
    # Cap on stored requirement entries.
    "max_entries": 12,
    # Per-run cap on pre-final "confirm the spec" continue nudges.
    "before_final_reminders": 1,
    # Longest stored entry (characters) before truncation.
    "max_entry_chars": 200,
}

# Generic, task-agnostic signal regexes. These describe *shapes* of stated
# requirements (units, obligation verbs, structural preconditions, absolute
# paths), not any particular task's answer.
_DEFAULT_PATTERNS = {
    "unit": (
        r"(?:\b\d[\d.,]*\s*)?"
        r"(?:cm\^?-?1|nm|GHz|MHz|kHz|Hz|eV|MeV|keV|m/s|km/h|dB|"
        r"\u00b0C|percent|%|bytes?|bits?|GiB|MiB|KiB|GB|MB|KB)\b"
    ),
    "requirement": (
        r"\b(?:must|shall|required?|ensure|exactly|at least|at most|"
        r"no (?:more|less) than|before the|after the|preserv\w*|"
        r"normaliz\w*|canonical\w*|re-?serializ\w*|whitespace|"
        r"sorted?|verbatim|byte-for-byte|identical|format)\b"
    ),
    "precondition": r"\bat least\s+\d+|\bbefore the\b[^.\n]*",
    "path": (
        r"(?<![\w:/])(?:"
        r"/(?:app|opt|tmp|home|root|workspace|data|srv|var|usr)/[\w./-]+"
        r"|/[\w./-]+\.[A-Za-z0-9]{1,8}\b"
        r")"
    ),
}

_config_cache: dict[str, dict] = {}


def _load_config(ctx) -> dict:
    """Read the ``spec_ledger`` block from the workspace agent.yaml."""
    cached = None
    root = getattr(getattr(ctx, "workspace", None), "root", None)
    if root is not None and yaml is not None:
        key = str(root)
        cached = _config_cache.get(key)
        if cached is None:
            cached = {}
            try:
                raw = yaml.safe_load(
                    (Path(root) / "agent.yaml").read_text(encoding="utf-8")
                )
                block = raw.get("spec_ledger") if isinstance(raw, dict) else None
                if isinstance(block, dict):
                    cached = dict(block)
            except Exception:
                cached = {}
            _config_cache[key] = cached
    cfg = dict(_DEFAULTS)
    if cached:
        cfg.update(cached)
    return cfg


def _positive_int(value, fallback: int) -> int:
    return value if isinstance(value, int) and value >= 0 else fallback


def _patterns(cfg: dict) -> dict:
    patterns = dict(_DEFAULT_PATTERNS)
    override = cfg.get("patterns")
    if isinstance(override, dict):
        for name, expr in override.items():
            if isinstance(expr, str) and expr:
                patterns[name] = expr
    return patterns


def _compile(patterns: dict) -> dict:
    compiled = {}
    for name, expr in patterns.items():
        try:
            compiled[name] = re.compile(expr, re.IGNORECASE)
        except re.error:
            continue
    return compiled


def _normalize(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def _extract_ledger(question: str, cfg: dict) -> list[dict]:
    """Pull requirement-bearing lines out of the task text.

    Returns a de-duplicated, ordered list of ``{"kind": ..., "text": ...}``.
    """
    compiled = _compile(_patterns(cfg))
    max_entries = _positive_int(cfg.get("max_entries"), _DEFAULTS["max_entries"])
    max_chars = _positive_int(
        cfg.get("max_entry_chars"), _DEFAULTS["max_entry_chars"]
    )
    if max_entries <= 0 or not compiled:
        return []

    # Split into line/sentence-ish fragments so a single long paragraph does not
    # collapse into one entry.
    fragments: list[str] = []
    for line in (question or "").splitlines():
        line = line.strip()
        if not line:
            continue
        # Keep bullet/list items whole, otherwise split on sentence enders.
        parts = re.split(r"(?<=[.;:])\s+(?=[A-Z0-9/])", line) or [line]
        fragments.extend(parts if parts else [line])

    entries: list[dict] = []
    seen: set[str] = set()
    for frag in fragments:
        text = _normalize(frag)
        if not text:
            continue
        matched = [name for name, rx in compiled.items() if rx.search(text)]
        if not matched:
            continue
        if len(text) > max_chars:
            text = text[: max_chars - 1].rstrip() + "\u2026"
        key = text.lower()
        if key in seen:
            continue
        seen.add(key)
        entries.append({"kind": ",".join(matched), "text": text})
        if len(entries) >= max_entries:
            break
    return entries


def _ensure_ledger(ctx, cfg: dict) -> list[dict]:
    """Parse the question once and persist the ledger in agent state."""
    existing = ctx.state.get("spec_ledger")
    if ctx.state.get("spec_ledger_parsed") and isinstance(existing, list):
        return existing
    ctx.state["spec_ledger_parsed"] = True
    entries = _extract_ledger(getattr(ctx, "question", "") or "", cfg)
    ctx.state["spec_ledger"] = entries
    ctx.trace.event(
        "spec_ledger_write",
        entries=len(entries),
        kinds=[e["kind"] for e in entries[:5]],
    )
    return entries


def _digest(entries: list[dict]) -> str:
    lines = [f"{i + 1}. [{e['kind']}] {e['text']}" for i, e in enumerate(entries)]
    return "\n".join(lines)


def _is_ledger_message(msg) -> bool:
    return (
        isinstance(msg, dict)
        and isinstance(msg.get("content"), str)
        and msg["content"].startswith(_LEDGER_PREFIX)
    )


def _reminder(entries: list[dict], *, final: bool) -> str:
    body = _digest(entries)
    if final:
        tail = (
            "Before submitting your final answer, confirm that EVERY entry "
            "above is satisfied by the artifact/answer you are about to give. "
            "If any entry is not satisfied, fix it with a tool call first; "
            "otherwise submit."
        )
    else:
        tail = (
            "Keep these task-stated requirements in force while you author the "
            "deliverable. Do not drop, reinterpret or silently normalize any "
            "entry without evidence from the task itself."
        )
    return (
        f"{_LEDGER_PREFIX} The task text states these checked requirements:\n"
        f"{body}\n{tail}"
    )


async def before_llm(messages, ctx):
    """Parse on the recon turn and re-inject the digest periodically."""
    cfg = _load_config(ctx)
    if not cfg.get("enabled", True):
        return messages

    entries = _ensure_ledger(ctx, cfg)

    # Drop any stale reminder so it does not accumulate across turns.
    if isinstance(messages, list):
        cleaned = [m for m in messages if not _is_ledger_message(m)]
    else:
        cleaned = messages

    if not entries:
        return cleaned

    interval = _positive_int(
        cfg.get("remind_interval_turns"), _DEFAULTS["remind_interval_turns"]
    )
    if interval <= 0:
        return cleaned
    turn = getattr(ctx, "turn", 0) or 0
    if turn % interval != 0:
        return cleaned

    if not isinstance(cleaned, list):
        return messages
    ctx.trace.event("spec_ledger_remind", turn=turn, entries=len(entries))
    return cleaned + [{"role": "user", "content": _reminder(entries, final=False)}]


async def before_final(answer, ctx):
    """Once, ask the agent to confirm each ledger entry before submitting."""
    cfg = _load_config(ctx)
    if not cfg.get("enabled", True):
        return None

    entries = ctx.state.get("spec_ledger")
    if not isinstance(entries, list) or not entries:
        return None

    max_fires = _positive_int(
        cfg.get("before_final_reminders"), _DEFAULTS["before_final_reminders"]
    )
    fires = ctx.state.get("spec_ledger_final_fires") or 0
    if not isinstance(fires, int):
        fires = 0
    if fires >= max_fires:
        return None
    ctx.state["spec_ledger_final_fires"] = fires + 1
    ctx.trace.event("spec_ledger_final_check", entries=len(entries))
    return {
        "action": "continue",
        "feedback": _reminder(entries, final=True),
    }