"""Reasoning-action guard.

Observed failure mode: a single planning turn consumes the entire output
budget as reasoning (``reasoning_tokens == completion_tokens``), returns empty
content with no tool call, and the run dies before any artifact is produced
(monotone empty-content truncation on long plans).

This middleware is consulted by the turn loop just before a turn is accepted
or errored. It detects a turn that spent the generation budget on reasoning
without emitting a tool call, and asks the runtime to re-issue that turn with

  (a) a directive that forces the next concrete tool call, and
  (b) a reduced output budget that reserves a floor for the action channel,

so a planning-only truncation cannot silently repeat and burn the whole run.
It is intentionally generic: it reasons about turn shape (content/reasoning/
tool calls/truncation) plus a small config block, not about task content.
"""

from __future__ import annotations

from pathlib import Path

try:  # pragma: no cover - PyYAML is a hard dependency of the workspace loader
    import yaml
except Exception:  # pragma: no cover
    yaml = None

_DEFAULTS = {
    "enabled": True,
    # Characters of accumulated reasoning in one turn before an action is forced.
    "reasoning_cap": 24000,
    # Output-token floor kept for the action channel on a forced retry.
    "reserved_action_tokens": 4096,
    # Per-run cap on forced-action retries (protects against loops).
    "max_forces": 2,
}

_config_cache: dict[str, dict] = {}


def _load_config(ctx) -> dict:
    """Read the ``reasoning_action_guard`` block from the workspace agent.yaml."""
    cached = None
    root = getattr(getattr(ctx, "workspace", None), "root", None)
    if root is not None and yaml is not None:
        key = str(root)
        cached = _config_cache.get(key)
        if cached is None:
            cached = {}
            try:
                raw = yaml.safe_load(
                    (Path(root) / "agent.yaml").read_text(encoding="utf-8")
                )
                block = raw.get("reasoning_action_guard") if isinstance(raw, dict) else None
                if isinstance(block, dict):
                    cached = {
                        name: block[name]
                        for name in _DEFAULTS
                        if name in block
                    }
            except Exception:
                cached = {}
            _config_cache[key] = cached
    cfg = dict(_DEFAULTS)
    if cached:
        cfg.update(cached)
    return cfg


def _positive_int(value, fallback: int) -> int:
    return value if isinstance(value, int) and value > 0 else fallback


def _reasoning_tokens(usage: dict):
    for field in ("output_tokens_details", "completion_tokens_details"):
        details = usage.get(field)
        if isinstance(details, dict):
            value = details.get("reasoning_tokens")
            if isinstance(value, int):
                return value
    return None


def _output_tokens(usage: dict):
    for field in ("output_tokens", "completion_tokens"):
        value = usage.get(field)
        if isinstance(value, int):
            return value
    return None


def _directive(reasoning_cap: int, reserved: int) -> str:
    return (
        "STOP PLANNING AND ACT NOW. Your previous attempt spent the output "
        "budget on reasoning without emitting any tool call, so no progress "
        "was recorded. Do not continue that derivation. Immediately emit the "
        "single next concrete tool call (the `shell` tool) that writes, "
        "creates or updates the required output artifact, using a short "
        "command. Keep reasoning brief "
        f"(well under {reasoning_cap} characters) and reserve at least "
        f"{reserved} output tokens for the tool call and its arguments. If "
        "the task is already finished, return the final answer text instead "
        "of a tool call."
    )


async def turn_guard(info, ctx):
    cfg = _load_config(ctx)
    if not cfg.get("enabled", True) or not isinstance(info, dict):
        return None
    if info.get("last_turn"):
        # No further turn exists to carry a forced action.
        return None
    if info.get("n_tool_calls"):
        return None
    content = info.get("content") or ""
    if content.strip():
        # A real final answer was produced; leave it to the final-answer gate.
        return None

    reasoning = info.get("reasoning") or ""
    usage = info.get("usage") if isinstance(info.get("usage"), dict) else {}
    reasoning_tokens = _reasoning_tokens(usage)
    output_tokens = _output_tokens(usage)
    truncated = bool(info.get("truncated"))

    reasoning_cap = _positive_int(cfg.get("reasoning_cap"), _DEFAULTS["reasoning_cap"])
    reserved = _positive_int(
        cfg.get("reserved_action_tokens"), _DEFAULTS["reserved_action_tokens"]
    )
    max_tokens = info.get("max_tokens")

    # Fire only on a genuine planning-only turn:
    #   * the whole budget was consumed (truncated), or
    #   * reasoning alone exceeded the configured length cap, or
    #   * reasoning ate into the reserved action-token floor.
    action_floor_breached = (
        isinstance(reasoning_tokens, int)
        and isinstance(max_tokens, int)
        and reasoning_tokens >= max(max_tokens - reserved, 1)
    )
    budget_exhausted = (
        truncated
        or len(reasoning) >= reasoning_cap
        or action_floor_breached
    )
    if not budget_exhausted:
        return None

    max_forces = _positive_int(cfg.get("max_forces"), _DEFAULTS["max_forces"])
    fires = ctx.state.get("turn_guard_fires") or 0
    if not isinstance(fires, int):
        fires = 0
    if fires >= max_forces:
        ctx.trace.event("turn_guard_budget_exceeded", fires=fires, budget=max_forces)
        return None
    ctx.state["turn_guard_fires"] = fires + 1

    # Reserve the action floor for the retry: keep roughly the reserved action
    # tokens after whatever the previous turn consumed, never exceeding the
    # original budget. A fully exhausted turn -> retry gets only the floor.
    retry_tokens = None
    if isinstance(max_tokens, int) and max_tokens > 0:
        consumed = reasoning_tokens if isinstance(reasoning_tokens, int) else 0
        retry_tokens = max(reserved, min(max_tokens, max_tokens - consumed + reserved))

    ctx.trace.event(
        "turn_guard_force_action",
        turn=info.get("turn"),
        truncated=truncated,
        reasoning_len=len(reasoning),
        reasoning_tokens=reasoning_tokens,
        output_tokens=output_tokens,
        retry_max_tokens=retry_tokens,
        fires=fires + 1,
    )
    decision = {
        "action": "force_action",
        "directive": _directive(reasoning_cap, reserved),
    }
    if retry_tokens:
        decision["max_tokens"] = retry_tokens
    return decision