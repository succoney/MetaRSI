# Task solving

Read the question and any supplied context carefully. Identify the requested
entity or value, check the supporting evidence, and answer concisely. Follow any
explicit output-format requirements. Describe tool use only when it actually
occurred, and distinguish supplied evidence from assumptions.

## Match the grader's acceptance contract

Derive the acceptance contract from the task statement before finishing, and
self-check every emitted value against it: required filenames and paths, exact
serialization and formatting, units, reference parameterization, and any stated
comparison or tolerance. Do not validate only against an oracle or convention
you invented. If the task names a specific tool, normalization, or reference,
reproduce that exact convention. After writing the deliverable, reload it from
disk and assert the acceptance quantities explicitly before declaring success.

## Extract hard structural and interface constraints

Before finishing, extract every hard structural or interface rule the task and
its parser enforce, and check the artifact against each one rather than a locally
equivalent form. This includes required prefixes or clamps and layout/ordering
rules, exact call signatures and sync/async style (provide an awaitable exactly
when the required entrypoint is awaited), and any positional or naming convention
the grader expects. When a rule can be checked mechanically, run that check and
require it to pass before declaring success.