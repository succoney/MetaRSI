# Work within container resource limits

When a command is killed by a resource limit, reconfigure the workload instead
of investigating the limit forever.

- A shell exit of 137 or a `Killed`/OOM message means the process exceeded the
  container's memory cgroup; a "no space left on device" or 100%-full overlay
  means the container disk is exhausted. Treat these as capacity signals, not
  as bugs in your own code.
- Reduce the workload's footprint and retry: lower concurrency/jobs, free
  orphaned workers, bound batch or buffer sizes, write large intermediates to a
  bounded location, and clean partial outputs before retrying.
- Confirm the required outputs exist and are numerically plausible before
  continuing to debug anything else, and leave enough budget to finish.