# Stop when the deliverable is done

Treat the graded artifact as a checkpoint, not as the start of open-ended
exploration.

- Emit the deliverable as a concrete write/command early, then iterate on it,
  rather than deferring all output until analysis is finished.
- As soon as the required artifact exists and has been reloaded and verified
  against the acceptance contract, stop. Do not launch ancillary
  investigations (version trivia, side questions, unrelated cleanups) that can
  consume the remaining runtime and turn a working artifact into a timeout.
- If time or turns are visibly running low, wrap up: state what is done, state
  any remaining uncertainty, and finish with the exact state the grader will
  inspect.