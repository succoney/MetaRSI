# Verify against the acceptance contract

Your own equivalence test is not the grader. Before finishing, derive the
acceptance contract from the task statement itself and check every required
output field against it.

- Re-read the task and extract the exact compared quantities, the required
  serialization/normalization, units, ordering, and any stated tolerances
  (absolute, relative, or percent).
- When the task names a reference model, parameterization, or published
  baseline, reproduce that reference first and confirm the local model matches
  it, instead of inventing a convention that merely looks self-consistent.
- Reload the deliverable from disk and recompute each graded quantity with
  explicit assertions against the extracted contract and tolerances. A locally
  consistent result that uses a different normalization or parameter
  convention still fails.
- If a field's expected convention is ambiguous, prefer the one the task's own
  wording, examples, or tolerance implies, and say which you chose.