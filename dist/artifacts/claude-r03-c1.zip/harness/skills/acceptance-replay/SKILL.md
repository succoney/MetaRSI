---
name: acceptance-replay
description: Use before declaring any task complete, and whenever the deliverable's output contract could be read more than one way (unit or coordinate scale, address base or key keyspace, serializer or key/attribute order, required prefix/spacer/clamp, normalized comparison). Turns the statement's acceptance comparison into an executed script run against the artifact on disk, resolves any implicit convention to a reported value, and re-derives the graded input when your own model looks degenerate.
---

# Acceptance replay

Goal: the last check before finishing is the task's own comparison, executed,
not restated. A check that lives only in reasoning, or that only confirms your
own model against itself, is not acceptance.

1. Write the contract down first, from the statement alone: the exact artifact
   path and name, the output grammar (encoding, delimiters, key/attribute
   order, required prefix/suffix/spacer/clamp, line or element counts), and
   what the success criterion actually compares — set equality over all valid
   answers, equality after a normalization of the input, numeric equality
   within a tolerance on a named unit/coordinate scale, or a literal command's
   exit status and output.
2. Write that check as a small script file and run it in a fresh process
   (`python3 -I`, or the interpreter the statement names) against the artifact
   read back from disk, using the statement's literal command, entry point,
   arguments and paths. Assert structural grammar literally (a regexp or offset
   assertion), not merely that a substring occurs.
3. For every element the statement leaves implicit — a unit or coordinate
   scale, an address base or key keyspace, a serializer or ordering, an offset
   or required spacer such as a clamp before a recognition site — enumerate the
   candidate conventions and keep the one consistent with the statement's own
   example and with the object actually graded. Report the resolved numeric
   value or literal form in the final answer. Do not ship a documented caveat,
   and do not accept a self-consistent convention you cannot tie to the stated
   contract.
4. If the task asks for all valid answers, assert set equality over the full
   candidate space. If your own enumerator, parser or model returns an
   anomalously degenerate result, or contradicts something you verified
   earlier, re-derive the disputed input from the source evidence — do not
   re-run the same model and treat its agreement as acceptance.
5. Report the measured value against the stated tolerance so a borderline pass
   is visible, and retune a thin margin before finishing.

Exit condition: every requirement the statement names has been reproduced by an
executed check, and every convention you resolved has a reported value. Then
stop; do not add further variants of the same check.