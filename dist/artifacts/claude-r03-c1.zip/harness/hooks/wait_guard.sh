#!/bin/sh
# PreToolUse guard for the Bash tool (wired in hooks.json).
#
# NEW IN THIS EDIT, not an extension of anything: before it hooks/hooks.json was
# `{"hooks": {}}` and no execution-time Bash guard existed, so all three denials
# below are newly introduced behavior.
#
# It denies three unbounded-work shapes that measurably consumed whole runs and
# lost deliverables that were otherwise complete:
#   * an uncapped sleep-poll loop (rstan-to-pystan was killed at the wall-clock
#     limit on `until ls ...; do sleep 20; done` issued with a 3,000,000 ms tool
#     timeout, with its deliverables already complete)
#   * a single tool timeout of 1,000,000 ms or more, long enough to outlive the
#     remaining run budget
#   * a fire-and-forget background start (nohup/setsid/disown ... &) left
#     running when the episode ends, so the artifact it was meant to produce is
#     never written (compile-compcert: `nohup env DUNEJOBS=1 make -j1 ... &`)
# Every denial names a bounded replacement.
#
# Only those shapes are matched; everything else is left untouched:
#   * only `until <cond> ... do ... sleep` and `while true`/`while :` ... `do ...
#     sleep` are poll loops, so `for` loops and conditional `while <test>` retry
#     loops are not matched at all;
#   * a poll loop is denied only when nothing in the command bounds it: a `for`
#     list, a `{a..b}` range, a counter increment (`n++`, `$((n+1))`), a numeric
#     comparison, `SECONDS`, a named deadline/attempt bound, or a `timeout N`
#     applied to the loop itself. A per-iteration `timeout 2` inside an
#     otherwise uncapped loop does not count, because that loop can still run
#     forever;
#   * the backgrounding `&` must terminate the nohup/setsid/disown command, so
#     `&&` and `2>&1` never match: `nohup x >log 2>&1 && cp out /dst` is not
#     denied. `run_in_background` tool jobs are not matched either;
#   * every pattern is anchored on the `"command"` JSON field, and its gap class
#     excludes an unescaped `"` (allowing `\"`), so a match cannot leave the
#     command string and prose in another field cannot trigger a deny.
#
# Bounded by construction: reads stdin once, no loops, grep is the only external
# command, and it fails open (any error denies nothing).
input=$(cat 2>/dev/null)
reason=""

# Does the command itself bound a sleeping loop with an explicit attempt cap or
# deadline? If so, the loop below is a bounded retry and is left alone.
bound=0
printf '%s' "$input" | grep -Eq '"command"[[:space:]]*:[[:space:]]*"([^"]|\\.){0,3000}(timeout[[:space:]]+[0-9]+[[:space:]]+([^"]|\\.){0,200}(until|while)|for[[:space:]]([^"]|\\.){0,60}in[[:space:]]|[{][0-9]+[.][.][0-9]+[}]|[+][+]|\$\(\(|[-](lt|gt|le|ge|eq|ne)|SECONDS|deadline|attempts?[[:space:]]*=)' && bound=1

if [ "$bound" = 0 ] && printf '%s' "$input" | grep -Eq '"command"[[:space:]]*:[[:space:]]*"([^"]|\\.){0,2000}(until[[:space:]]([^"]|\\.){0,400}do|while[[:space:]]+(true|:)([[:space:]]|;|\\)*([^"]|\\.){0,300}do)([^"]|\\.){0,300}sleep'; then
  reason="Blocked by harness wait-guard (new in this harness revision): a sleep-poll loop with no attempt cap can consume the whole run budget after the deliverable already exists. Bounded alternatives: start the job with run_in_background and check the real interface with one short command; or poll with a capped loop, for example: for i in 1 2 3 4 5; do <check> && break; sleep 2; done, and decide explicitly what to do when the attempts are exhausted. If the required artifact already exists and its acceptance check passes, conclude instead of waiting."
elif printf '%s' "$input" | grep -Eq '"timeout"[[:space:]]*:[[:space:]]*[0-9]{7,}'; then
  reason="Blocked by harness wait-guard (new in this harness revision): a single Bash timeout of 1,000,000 ms or more can outlive the remaining session budget and lose a deliverable that is already complete. Use a bounded timeout (for example 120000) with a capped retry loop, or run the long job with run_in_background and poll the real interface with short bounded checks."
elif printf '%s' "$input" | grep -Eq '"command"[[:space:]]*:[[:space:]]*"([^"]|\\.){0,2000}(nohup|setsid|disown)([[:space:]]|;|\\)([^"]|\\.){0,400}[^&>]&([^&]|$)'; then
  reason="Blocked by harness build-guard (new in this harness revision): a fire-and-forget background start (nohup/setsid/disown ... &) is left running when the episode ends, and the artifact it was meant to produce is never written. Do not background a from-source prerequisite build. Bounded alternatives: check whether a compatible version is already installed (command -v, --version) and use it instead; if you must build, run it in the foreground with a short explicit timeout, validate the produced tool end to end on a trivial input, and if the deadline passes without the prerequisite usable, abandon the build and report the blocked condition with the version mismatch. Use run_in_background only for a job you will poll with short bounded checks and whose absence will not leave a required artifact unwritten."
fi

[ -z "$reason" ] && exit 0

printf '{"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"deny","permissionDecisionReason":"%s"}}' "$reason"