# Task completion discipline

The deliverable in these tasks is graded by an external checker whose exact
comparison is not visible to us. The most expensive failure is a complete,
well-formed artifact that satisfies our own reasoning and not the checker's
contract. These rules apply to every task.

## Acceptance comes from the task's contract, not from your own oracle

- Reconstruct the acceptance check from the task statement's stated output
  contract before you finish, and reproduce it literally: run the exact
  commands, entry points and paths the statement names, end to end, against the
  artifact you actually persisted on disk.
- When the contract implies a canonical or normalized form (serialization,
  attribute or key ordering, whitespace), a structural grammar (required prefix,
  suffix, spacer, delimiter or clamp), or a unit / coordinate / scale
  convention, assert that exact form. Byte-fidelity to the input, or internal
  self-consistency, is not a substitute for it.
- A check you wrote that validates your own assumptions is not acceptance.
  Where possible read the artifact back from disk in a fresh process and
  recompute the metric independently of the code that produced it.
- A comparison that passes without matching anything is not evidence. Before you
  accept a comparison, assert it is non-vacuous: for key or set comparisons the
  overlap must be non-empty, and any coverage / recall bar must be measured and
  reported as a number against the stated threshold. A disjoint key set, an empty
  intersection or 0% coverage is a failure signal about the convention, not a
  satisfied requirement.
- When you encode the graded input into a machine-readable model (board, grid,
  key set, intermediate JSON), assert that the model reproduces your
  independently observed reading item by item rather than only being
  self-consistent: round-trip the serialization back to the reading it claims to
  represent. Any disagreement between the printed model and that reading, and any
  degenerate result (empty, duplicate, or a single element where the contract
  implies a set), is a defect signal — re-derive the disputed element from the
  source instead of re-running the same model.
- If a unit, scale or coordinate convention is ambiguous, resolve it from an
  invariant tied to the graded quantity (a known physical reference, the graded
  object's own metadata, or a tolerance satisfiable in only one convention), not
  from plausibility, convenience or the input file's own coordinates, and apply
  the resolved convention to the primary reported fields rather than as a closing
  caveat. Do not ship a documented caveat in place of resolving it.
- When the task asks for all valid answers, assert set equality over the whole
  candidate space, not membership of one representative result.

## Land the artifact first; bound all self-directed work

- Produce and persist the required artifact at the required path on an early
  tool cycle, before extended analysis, derivation or builds, and refine it in
  place, so a budget overrun still leaves a graded artifact behind.
- Delegate long derivations and experiments to short, bounded tool steps with
  explicit timeouts rather than continuous reasoning, and keep single responses
  well under the per-response output ceiling.
- Every verification, wait or background job you start must carry an explicit
  timeout and an exit condition, and no poll loop may outlive the remaining
  budget. Do not start an open-ended confirmation after the deliverables exist
  and a local check has passed — conclude instead.
- Clear a toolchain gate by the shortest route to a version the tool itself
  accepts, including any bypass the tool exposes, before declaring the gate
  blocking; read the required version range out of the tool's own configure or
  source first. Bound any prerequisite build by an explicit deadline and keep it
  behind delivery of the target artifact. If the gate is genuinely unsatisfiable,
  keep that blocked condition as the current blocker and state it, rather than
  yielding with work still pending.