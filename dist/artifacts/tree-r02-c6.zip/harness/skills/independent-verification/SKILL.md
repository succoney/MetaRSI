---
name: independent-verification
description: Pre-submission verification protocol. Before emitting the final answer, restate the grader's own definition of every checked quantity, cross-check it with an independently-implemented oracle, and reproduce the grader's actual delivery/environment path instead of re-running your implementation's own assumption.
---

# Independent verification before submission

A self-test only proves that your implementation is consistent with *its own*
model of the spec. When the grader's definition or delivery path differs, the
self-test still reports "all checks passed" while the grader disagrees. Run this
protocol before emitting the final answer, and do not submit while any
independent check disagrees.

## Protocol

1. **Enumerate the checked quantities.** List every value, file, or behavior the
   task says will be graded. For each, quote or restate the *grader's* definition
   from the task text (units, window/extent, normalization, exact represen-
   tation). Do not reuse your implementation's internal definition.

2. **Build an independent oracle.** For each checked quantity, write a second
   check that uses a *different* library or a *different* algorithm than the
   artifact. Two checks that share the same function, loop, or assumption are
   not independent. Prefer a closed-form, a reference library, or a brute-force
   enumeration.

3. **Reproduce the grader's delivery / environment path.** Reproduce *how* the
   grader obtains the quantity, not just *what* it computes. Watch for these
   recurring boundaries:
   - **Signal delivery.** If the grader launches the artifact and signals it,
     deliver the signal to an *external* process (process group) with
     `run_external.py` below. An in-process `os.kill(os.getpid(), SIGINT)` or a
     directly-called cleanup handler exercises a different path and can hide a
     failure.
   - **Definitional extent.** Use the full extent the grader uses. Do not
     truncate to a convenient prefix/suffix (e.g. a tract that the grader
     extends with adjacent/overhang regions); compute the quantity over the
     whole definitional range.
   - **Serialization.** If the grader re-parses and re-serializes the artifact's
     output, compare against the parser's *canonical* re-serialization with the
     grader's normalization (e.g. whitespace-stripped), not against your raw
     input or your own byte-preserving output.

4. **Reconcile.** If the independent oracle and the artifact disagree on the
   checked dimension, treat the oracle as authoritative: re-read the task text,
   fix the artifact (or your reading of the spec), then re-run step 2–3. Only
   submit once the independent check agrees.

5. **Record.** Before the final answer, note the grader definitions you restated
   and the independent-check results, so a passing report means the *grader's*
   definition was satisfied.

## External-signal helper

`run_external.py` (next to this file) launches a target command as its own
process and can deliver a signal to the whole process group, so in-process
self-tests cannot substitute for the grader's external delivery. Example::

    python3 skills/independent-verification/run_external.py \
        --signal SIGINT --wait 1.0 -- python3 app.py

If the helper file is not reachable from your working directory, use this
equivalent form inline::

    python3 - <<'PY'
    import json, os, signal, subprocess, sys, time
    wait = 1.0
    p = subprocess.Popen(sys.argv[1:] if len(sys.argv) > 1 else ["python3", "app.py"],
                         stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT, start_new_session=True)
    time.sleep(wait)
    os.killpg(p.pid, signal.SIGINT)          # external, group-wide delivery
    out, _ = p.communicate(timeout=30)
    print(json.dumps({"exit_code": p.returncode,
                      "output": out.decode("utf-8", "replace")}))
    PY