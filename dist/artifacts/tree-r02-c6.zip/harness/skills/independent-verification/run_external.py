#!/usr/bin/env python3
"""Launch a target program as its own process and deliver external signals.

A grader that starts the artifact itself and signals the *process* (or its
process group) exercises a different code path than an in-process self-test
that calls the artifact's own cleanup handler (for example
``os.kill(os.getpid(), SIGINT)``).  This helper reproduces the external
delivery path so a pre-submission check cannot be satisfied by the artifact's
internal shortcut.

Examples
--------
Start ``app.py``, wait 1s, then send SIGINT to the whole process group and
report what the artifact flushed::

    python3 run_external.py --signal SIGINT --wait 1.0 -- python3 app.py

Run without signalling and just capture output / exit code::

    python3 run_external.py -- python3 app.py
"""

from __future__ import annotations

import argparse
import json
import os
import signal
import subprocess
import time


def run_external(argv, *, sig=None, wait=0.0, target="group", timeout=30.0):
    """Run ``argv`` externally and optionally deliver ``sig`` after ``wait`` s.

    ``target="group"`` delivers to the whole process group (the grader-style
    external delivery); ``target="process"`` delivers to the child only.
    Returns a dict with exit_code, signalled, signal, output, timed_out,
    delivered and pid.
    """
    proc = subprocess.Popen(
        argv,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        start_new_session=True,
    )
    delivered = False
    timed_out = False
    try:
        if wait:
            time.sleep(wait)
        if sig is not None:
            signum = getattr(signal, sig) if isinstance(sig, str) else int(sig)
            if target == "group":
                try:
                    os.killpg(proc.pid, signum)
                except ProcessLookupError:
                    pass
            else:
                try:
                    proc.send_signal(signum)
                except ProcessLookupError:
                    pass
            delivered = True
        try:
            out, _ = proc.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            out, _ = proc.communicate()
    except BaseException:
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        proc.wait()
        raise
    rc = proc.returncode
    return {
        "exit_code": rc,
        "signalled": rc is not None and rc < 0,
        "signal": -rc if rc is not None and rc < 0 else None,
        "output": (out or b"").decode("utf-8", errors="replace"),
        "timed_out": timed_out,
        "delivered": delivered,
        "pid": proc.pid,
    }


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Run a target externally and deliver a signal to it."
    )
    parser.add_argument(
        "--signal",
        default=None,
        help="signal name (e.g. SIGINT) or number to deliver after --wait",
    )
    parser.add_argument(
        "--wait",
        type=float,
        default=0.0,
        help="seconds to wait before delivering the signal",
    )
    parser.add_argument(
        "--target",
        choices=("group", "process"),
        default="group",
        help="deliver to the process group (default) or only the process",
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=30.0,
        help="seconds to wait for the target to exit after the signal",
    )
    parser.add_argument(
        "command",
        nargs=argparse.REMAINDER,
        help="'--' then the target command and its arguments",
    )
    args = parser.parse_args(argv)

    cmd = list(args.command)
    if cmd and cmd[0] == "--":
        cmd = cmd[1:]
    if not cmd:
        parser.error("provide a target command after '--'")

    result = run_external(
        cmd, sig=args.signal, wait=args.wait, target=args.target, timeout=args.timeout
    )
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())