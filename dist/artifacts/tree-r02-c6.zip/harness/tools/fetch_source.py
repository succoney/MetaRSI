"""Planned source-acquisition ladder.

Observed failure mode (selective egress / non-content responses): the canonical
way to obtain a remote source can be blocked or can serve a non-content body.
compile-compcert saw ``git clone`` time out against github.com:443 for 130811 ms
and the advertised ``https://compcert.org/pub/compcert-3.13.1.tar.gz`` return a
9379-byte *HTML document* (an HTTP 404 / GitHub Pages "Page not found"), while
``codeload.github.com`` served a valid 2.7 MB gzip. mteb-leaderboard saw
huggingface.co and raw.githubusercontent.com return 000 while codeload worked.

This module encodes a *planned, validated* acquisition ladder instead of
ad-hoc mirror probing. For a given ``owner``/``repo`` it walks an ordered list
of routes:

  1. ``git``             -- canonical ``git clone --depth 1`` over HTTPS (443)
  2. ``codeload_tar``    -- ``https://codeload.github.com/<owner>/<repo>/tar.gz/<ref>``
  3. ``codeload_zip``    -- ``https://codeload.github.com/<owner>/<repo>/zip/<ref>``
  4. ``github_archive``  -- ``https://github.com/<owner>/<repo>/archive/<ref>.tar.gz`` (mirror)
  5. ``pip``             -- a PyPI source distribution for the package
  6. ``apt``             -- a Debian source package

Every response produced by a route is validated before use: a body whose leading
bytes are an HTML/error page (e.g. ``<!DOCTYPE html>`` or a "404 / Page not
found" body mislabeled ``.tar.gz``) is rejected, and an archive is accepted only
if it really opens as a zip or tar (regardless of an unrecognized magic prefix).
A rejected route is discarded and the next route is tried. The route that
succeeded is recorded in ``ctx.state`` so later fetches reuse the working route
first (a small cache of reachable routes).

The public entry point mirrors the planned interface::

    fetch_source(owner, repo, ref=None, dest=...) -> dict

The runtime tool API (``async def call(args, ctx)``) adapts that to a JSON call.
"""

from __future__ import annotations

import asyncio
import json
import os
import shutil
import signal
import tarfile
import tempfile
import zipfile
from pathlib import Path

DEFAULT_TIMEOUT = 120.0
MIN_ARCHIVE_BYTES = 1

_KNOWN_ROUTES = (
    "git",
    "codeload_tar",
    "codeload_zip",
    "github_archive",
    "pip",
    "apt",
)

# Default ladder order, canonical route first (hypothesis order).
_DEFAULT_ROUTES = (
    "git",
    "codeload_tar",
    "codeload_zip",
    "github_archive",
    "pip",
    "apt",
)

_HTML_MARKERS = (
    b"<!doctype html",
    b"<html",
    b"<head",
    b"<title>404",
    b"page not found",
    b"404 not found",
    b"not found</title>",
)

_STATE_KEY = "fetch_source"


# ---------------------------------------------------------------------------
# low-level helpers
# ---------------------------------------------------------------------------


async def _exec(cmd: list[str], cwd: Path, timeout: float):
    """Run a command in its own process group; return (rc, timed_out, output).

    The process group is killed on timeout so a hung ``git clone`` cannot
    consume the whole run budget.
    """
    proc = None
    out = b""
    timed_out = False
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            cwd=str(cwd),
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
            start_new_session=True,
        )
        try:
            out, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        except asyncio.TimeoutError:
            timed_out = True
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            try:
                out, _ = await proc.communicate()
            except Exception:
                out = b""
    except Exception as exc:  # pragma: no cover - environment dependent
        return None, False, f"{type(exc).__name__}: {exc}"
    return proc.returncode, timed_out, (out or b"").decode("utf-8", errors="replace")


def _looks_like_html(head: bytes) -> bool:
    low = head[:2048].lstrip().lower()
    if not low:
        return False
    if (
        low.startswith(b"<!doctype")
        or low.startswith(b"<html")
        or low.startswith(b"<head")
        or low.startswith(b"<?xml")
        or low.startswith(b"<body")
    ):
        return True
    window = low[:512]
    return any(marker in window for marker in _HTML_MARKERS)


def _validate_archive(path: Path) -> tuple[str | None, str]:
    """Return (kind, detail); kind is 'zip'/'tar' only for real archives.

    A response that is an HTML/error page, or any body that does not actually
    open as a zip/tar, is rejected regardless of its advertised filename. This
    keeps a mislabeled error page from ever reaching ``tar``.
    """
    try:
        size = path.stat().st_size
    except OSError:
        return None, "missing download"
    if size < MIN_ARCHIVE_BYTES:
        return None, f"empty download ({size} bytes)"
    try:
        with open(path, "rb") as fh:
            head = fh.read(2048)
    except OSError as exc:
        return None, f"unreadable ({exc})"
    if _looks_like_html(head):
        return None, "HTML/error page, not an archive"
    try:
        if zipfile.is_zipfile(path):
            return "zip", f"zip ({size} bytes)"
    except Exception:
        pass
    try:
        if tarfile.is_tarfile(path):
            return "tar", f"tar ({size} bytes)"
    except Exception:
        pass
    return None, "unrecognized content (no zip/tar structure)"


def _download(url: str, dest: Path, timeout: float) -> tuple[bool, str]:
    """Stream ``url`` to ``dest``; capture error bodies for validation.

    A 404 that still returns an HTML body is reported as a failure *and* its
    bytes are written so the caller can prove why the route was rejected.
    """
    import urllib.error
    import urllib.request

    req = urllib.request.Request(url, headers={"User-Agent": "fetch_source/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            with open(dest, "wb") as fh:
                shutil.copyfileobj(resp, fh, 1 << 20)
        return True, f"http {getattr(resp, 'status', 200)}"
    except urllib.error.HTTPError as exc:
        try:
            body = exc.read()
            with open(dest, "wb") as fh:
                fh.write(body)
        except Exception:
            pass
        return False, f"http {exc.code}"
    except Exception as exc:
        return False, f"{type(exc).__name__}: {exc}"


def _route_key(owner: str, repo: str) -> str:
    return f"{owner}/{repo}".lower()


def _first_valid_archive(directory: Path) -> tuple[Path | None, str | None]:
    for candidate in sorted(directory.glob("*")):
        if candidate.is_file():
            kind, _detail = _validate_archive(candidate)
            if kind is not None:
                return candidate, kind
    return None, None


# ---------------------------------------------------------------------------
# route attempts
# ---------------------------------------------------------------------------


async def _attempt_git(owner, repo, ref, work, timeout):
    target = work / "git_clone"
    url = f"https://github.com/{owner}/{repo}.git"
    cmd = ["git", "clone", "--depth", "1"]
    if ref:
        cmd += ["--branch", ref]
    cmd += ["--", url, str(target)]
    rc, timed_out, out = await _exec(cmd, work, timeout)
    if rc == 0 and target.is_dir() and any(target.iterdir()):
        return True, "git clone ok", target, "dir"
    shutil.rmtree(target, ignore_errors=True)
    reason = "timeout" if timed_out else f"rc={rc}"
    return False, f"{url} -> {reason}: {out[-200:]}", None, None


async def _attempt_download(route, owner, repo, ref, work, timeout):
    ref = ref or "HEAD"
    if route == "codeload_tar":
        url = f"https://codeload.github.com/{owner}/{repo}/tar.gz/{ref}"
    elif route == "codeload_zip":
        url = f"https://codeload.github.com/{owner}/{repo}/zip/{ref}"
    else:  # github_archive
        url = f"https://github.com/{owner}/{repo}/archive/{ref}.tar.gz"
    dest = work / f"dl_{route}"
    ok, detail = await asyncio.to_thread(_download, url, dest, timeout)
    if not ok:
        return False, f"{url} -> {detail}", None, None
    kind, why = _validate_archive(dest)
    if kind is None:
        return False, f"{url} -> rejected: {why}", dest, None
    return True, f"{url} -> {why}", dest, kind


async def _attempt_pip(repo, work, timeout):
    target = work / "pip"
    target.mkdir(exist_ok=True)
    cmd = [
        "pip",
        "download",
        "--no-deps",
        "--no-binary",
        ":all:",
        "--dest",
        str(target),
        repo,
    ]
    rc, timed_out, out = await _exec(cmd, work, timeout)
    archive, kind = _first_valid_archive(target)
    if rc == 0 and archive is not None:
        return True, f"pip sdist {archive.name}", archive, kind
    reason = "timeout" if timed_out else f"rc={rc}"
    return False, f"pip download {repo} -> {reason}: {out[-200:]}", None, None


async def _attempt_apt(repo, work, timeout):
    target = work / "apt"
    target.mkdir(exist_ok=True)
    rc, timed_out, out = await _exec(["apt-get", "source", repo], target, timeout)
    archive, kind = _first_valid_archive(target)
    if archive is None:
        # apt-get source may drop sources into an extracted tree; find any archive
        for candidate in target.glob("*.tar.*"):
            kind, _ = _validate_archive(candidate)
            if kind is not None:
                archive = candidate
                break
    if archive is not None:
        return True, f"apt source {archive.name}", archive, kind
    reason = "timeout" if timed_out else f"rc={rc}"
    return False, f"apt-get source {repo} -> {reason}: {out[-200:]}", None, None


async def _attempt(route, owner, repo, ref, work, timeout):
    if route == "git":
        return await _attempt_git(owner, repo, ref, work, timeout)
    if route in ("codeload_tar", "codeload_zip", "github_archive"):
        return await _attempt_download(route, owner, repo, ref, work, timeout)
    if route == "pip":
        return await _attempt_pip(repo, work, timeout)
    if route == "apt":
        return await _attempt_apt(repo, work, timeout)
    return False, f"unknown route {route!r}", None, None


# ---------------------------------------------------------------------------
# finalization (move / extract into dest)
# ---------------------------------------------------------------------------


def _prepare_dest(dest: Path, overwrite: bool) -> None:
    if not dest.exists():
        dest.parent.mkdir(parents=True, exist_ok=True)
        return
    if overwrite:
        if dest.is_dir():
            shutil.rmtree(dest)
        else:
            dest.unlink()
        dest.parent.mkdir(parents=True, exist_ok=True)
        return
    if dest.is_dir() and not any(dest.iterdir()):
        return
    raise FileExistsError(f"destination {dest} already exists (pass overwrite=true)")


def _finalize(produced: Path, kind: str, dest: Path, overwrite: bool) -> None:
    _prepare_dest(dest, overwrite)
    if kind == "dir":
        shutil.move(str(produced), str(dest))
        return
    # Archive: extract, then flatten a single top-level directory to dest.
    staging = Path(tempfile.mkdtemp(prefix="fetchsrc_x_", dir=str(dest.parent)))
    try:
        if kind == "zip":
            with zipfile.ZipFile(produced) as zf:
                zf.extractall(staging)
        else:
            with tarfile.open(produced, "r:*") as tf:
                try:
                    tf.extractall(staging, filter="data")
                except TypeError:  # Python < 3.12 has no filter kwarg
                    tf.extractall(staging)
        entries = list(staging.iterdir())
        root = entries[0] if len(entries) == 1 and entries[0].is_dir() else staging
        shutil.move(str(root), str(dest))
    finally:
        shutil.rmtree(staging, ignore_errors=True)


# ---------------------------------------------------------------------------
# route cache (ctx.state) + ordering
# ---------------------------------------------------------------------------


def _route_store(ctx) -> dict:
    try:
        return ctx.state[_STATE_KEY]
    except Exception:
        try:
            ctx.state[_STATE_KEY] = {}
            return ctx.state[_STATE_KEY]
        except Exception:
            return {}


def _cached_route(ctx, owner, repo):
    store = _route_store(ctx)
    routes = store.get("routes") if isinstance(store, dict) else None
    if isinstance(routes, dict):
        hit = routes.get(_route_key(owner, repo))
        if hit:
            return hit
    if isinstance(store, dict):
        return store.get("last_route")
    return None


def _remember_route(ctx, owner, repo, route) -> None:
    store = _route_store(ctx)
    if not isinstance(store, dict):
        return
    routes = store.setdefault("routes", {})
    if isinstance(routes, dict):
        routes[_route_key(owner, repo)] = route
    store["last_route"] = route


def _order_routes(routes, ctx, owner, repo):
    base = [r for r in (routes or _DEFAULT_ROUTES) if r in _KNOWN_ROUTES]
    if not base:
        base = list(_DEFAULT_ROUTES)
    cached = _cached_route(ctx, owner, repo)
    if cached in base:
        base.remove(cached)
        base.insert(0, cached)
    return base


# ---------------------------------------------------------------------------
# public API
# ---------------------------------------------------------------------------


async def fetch_source(
    owner: str,
    repo: str,
    ref: str | None = None,
    dest=None,
    *,
    ctx,
    routes=None,
    timeout: float = DEFAULT_TIMEOUT,
    overwrite: bool = False,
) -> dict:
    """Acquire ``owner/repo`` (optionally at ``ref``) into ``dest`` via a ladder.

    Walks the ordered, validated route ladder, rejecting any non-content
    response, and returns ``{"ok", "route", "dest", "attempts", ...}``. The
    winning route is remembered in ``ctx.state`` and reused first next time.
    """
    if not owner or not repo:
        raise ValueError("owner and repo are required")

    base = Path(getattr(ctx, "working_dir", None) or Path.cwd()).resolve()
    dest_path = Path(dest) if dest else base / repo
    if not dest_path.is_absolute():
        dest_path = base / dest_path

    ladder = _order_routes(routes, ctx, owner, repo)
    work = Path(tempfile.mkdtemp(prefix="fetchsrc_"))
    attempts: list[dict] = []
    trace = getattr(ctx, "trace", None)
    try:
        for route in ladder:
            try:
                ok, detail, produced, kind = await _attempt(
                    route, owner, repo, ref, work, float(timeout)
                )
            except Exception as exc:  # a route failure must not abort the ladder
                ok, detail, produced, kind = False, f"{type(exc).__name__}: {exc}", None, None
            attempts.append({"route": route, "ok": ok, "detail": str(detail)[:300]})
            if not ok:
                continue
            try:
                _finalize(produced, kind, dest_path, overwrite)
            except Exception as exc:
                attempts[-1]["ok"] = False
                attempts[-1]["finalize_error"] = str(exc)
                continue
            _remember_route(ctx, owner, repo, route)
            if trace is not None:
                try:
                    trace.event(
                        "acquisition_route",
                        owner=owner,
                        repo=repo,
                        ref=ref,
                        route=route,
                        dest=str(dest_path),
                    )
                except Exception:
                    pass
            return {
                "ok": True,
                "route": route,
                "dest": str(dest_path),
                "detail": detail,
                "attempts": attempts,
            }
        return {"ok": False, "dest": str(dest_path), "attempts": attempts}
    finally:
        shutil.rmtree(work, ignore_errors=True)


async def call(args, ctx) -> str:
    """Tool entry point: validate args and run the acquisition ladder."""
    owner = args.get("owner")
    repo = args.get("repo")
    if not isinstance(owner, str) or not owner.strip():
        raise ValueError("owner must be a non-empty string")
    if not isinstance(repo, str) or not repo.strip():
        raise ValueError("repo must be a non-empty string")
    ref = args.get("ref")
    if ref is not None and not isinstance(ref, str):
        raise ValueError("ref must be a string when provided")
    dest = args.get("dest")
    if dest is not None and not isinstance(dest, str):
        raise ValueError("dest must be a string when provided")
    routes = args.get("routes")
    if routes is not None and not (
        isinstance(routes, list) and all(isinstance(r, str) for r in routes)
    ):
        raise ValueError("routes must be a list of route names when provided")
    timeout = args.get("timeout", DEFAULT_TIMEOUT)
    if type(timeout) not in (int, float) or timeout <= 0:
        raise ValueError("timeout must be a positive number")
    overwrite = bool(args.get("overwrite", False))

    result = await fetch_source(
        owner.strip(),
        repo.strip(),
        ref=(ref.strip() if isinstance(ref, str) and ref.strip() else None),
        dest=dest,
        ctx=ctx,
        routes=routes,
        timeout=float(timeout),
        overwrite=overwrite,
    )
    return json.dumps(result, ensure_ascii=False)