---
name: model-serialization-roundtrip
description: Use when a graded input must be translated from non-text evidence (an image, screenshot, diagram, physical layout, or a prose description) into a machine-readable model (a serialized state string, JSON, config, or coordinate list) that is the sole input to your own enumerator, solver or simulator, and again whenever the artifact you produce contradicts something you read earlier or your own tool returns a degenerate result. Forces the serialization to be round-tripped against an item-by-item inventory before it is trusted.
---

# Model serialization round-trip

The failure this avoids: the reading of the source is correct in one
representation (a per-item narration) but the literal serialization actually fed
to the solver silently omits an element, so a required answer is unreachable in
the candidate space and the solver can only confirm the truncated model against
itself.

## Procedure

1. **Inventory the source item by item.** From the non-text evidence, write out
   every element with its position/identifier (for example square-by-square, or
   one row per resistor/node/region). Keep this as a list with an explicit count
   per group, not as prose.

2. **Serialize, then parse the serialization back.** Write the machine-readable
   model (the exact string or structure the solver consumes), then, in a fresh
   process, parse that literal model and reconstruct the item-by-item inventory
   from it alone. Do not reconstruct it from your intended reading.

3. **Assert equality of the two inventories.** Element set and per-group counts
   must match exactly, in both directions. An element you narrated but that the
   parsed model lacks is a defect in the model, not a note to mention.

4. **Use only the reconciled model as the solver input,** and keep the
   round-trip assertion in the runnable check so it re-executes against the
   persisted model.

5. **Treat a degenerate or anomalous result as a re-derivation trigger.** If the
   solver returns fewer answers than the requirement implies (for example one
   item where a set is required), or anything contradicts an earlier verified
   reading, re-derive the disputed element from the source evidence. Do not
   re-run the same solver over the same model and count its agreement as
   acceptance.

## Exit condition

The parsed model reproduces the source inventory exactly (both directions), and
the answer set is produced from that reconciled model. Then stop.