# Task completion discipline

The deliverable in these tasks is graded by an external checker whose exact
comparison is not visible to us. The most expensive failure is a complete,
well-formed artifact that satisfies our own reasoning and not the checker's
contract. These rules apply to every task.

## Acceptance comes from the task's contract, not from your own oracle

- Reconstruct the acceptance check from the task statement's stated output
  contract before you finish, and reproduce it literally: run the exact
  commands, entry points and paths the statement names, end to end, against the
  artifact you actually persisted on disk.
- When the contract implies a canonical or normalized form (serialization,
  attribute or key ordering, whitespace), a structural grammar (required prefix,
  suffix, spacer, delimiter or clamp), or a unit / coordinate / scale
  convention, assert that exact form. Byte-fidelity to the input, or internal
  self-consistency, is not a substitute for it.
- A check you wrote that validates your own assumptions is not acceptance.
  Where possible read the artifact back from disk in a fresh process and
  recompute the metric independently of the code that produced it.
- When the deliverable is a mapping or serialization (addresses, identifiers,
  keys), do not accept it on the values it happens to share with your own
  reference. Recompute it with an independent second implementation, or against
  a second, independently produced instance of the problem's input, and assert
  equality of the identifier / key / address sets themselves, not only the
  values present in both. A key set that is disjoint from an independently
  derived one is a convention error even when every shared value is correct.
- If a convention is genuinely ambiguous, resolve it with an independent
  invariant or plausibility check and keep that check. Do not ship a documented
  caveat in place of resolving it.
- When the task asks for all valid answers, assert set equality over the whole
  candidate space, not membership of one representative result.
- Report the measured value against the stated tolerance, not only pass/fail.
  A check that only barely clears its threshold is not finished: retune it and
  re-measure before the artifact is accepted.
- Prove a required property of the deliverable (a forbidden dependency's
  absence, an installed path, a runtime guard, an exported symbol) by inspecting
  the artifact actually installed at the statement's path in a fresh process,
  not by trusting the build configuration, Makefile or in-tree copy that was
  supposed to produce it.

## Land the artifact first; bound all self-directed work

- Produce and persist the required artifact at the required path before
  extended analysis, derivation or exploration.
- Delegate long derivations and experiments to short, bounded tool steps with
  explicit timeouts rather than continuous reasoning.
- Every verification or wait step must be bounded: an explicit timeout and no
  poll loop that can outlive the remaining budget. Do not start an open-ended
  confirmation after the deliverables exist and a local check has passed —
  conclude instead.
- Keep the deliverable-producing step early so that a budget overrun still
  leaves a graded artifact behind.
- If a required dependency is unavailable, keep that blocked condition as the
  current blocker and state it, rather than yielding with work still pending.