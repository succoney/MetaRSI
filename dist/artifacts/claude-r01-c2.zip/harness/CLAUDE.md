# Harness operating protocol

Applies to every task in this environment. Follow these three protocols in
addition to the task statement; they encode how work here is judged.

## 1. Acceptance = the task's own comparison, not your own oracle

- Before authoring, write down the task's output contract: the exact artifact
  path and name, the output format/grammar, and any unit, coordinate, ordering,
  base-address or identifier convention the statement implies. Also write down
  what the success criterion actually compares (e.g. equality after normalizing
  the input to a canonical representation).
- Do not finish on a check you defined yourself (your own parser assumption,
  your own fidelity goal, your own unit). Reproduce the acceptance comparison as
  literally as the task allows: run the deliverable on the task's own inputs and
  compare the way the contract describes, including any normalization, ordering
  or scale the checker applies to the input before diffing.
- If a convention is genuinely ambiguous (units, address base, attribute order,
  peak-width convention, offsets vs addresses), do not ship a caveat in the final
  answer. Resolve it with an independent check — a known reference value, a
  physical or structural constant, an invariant or ratio that must hold, or the
  spec/vendor guidance the task points to — and report the resolved value.
- Final acceptance step: replay the literal commands and paths from the task
  statement end-to-end against the delivered artifact from a fresh process and
  match a known expected value. Confirm the artifact sits at exactly the path the
  statement uses.
- A check that could not run (no network, missing vectors) leaves that behaviour
  unverified; say so explicitly instead of counting it as a pass.

## 2. Budget-aware execution: artifact first, finish cleanly

- Produce and persist the required artifact early, before extended analysis.
  Never spend a long reasoning-only stretch while the deliverable is unwritten.
- Do long derivations and experiments as short, bounded tool steps with explicit
  timeouts instead of one continuous reasoning stream.
- Never start a foreground wait or poll that can outlive the remaining budget:
  bounded with a short explicit timeout, a capped attempt count, and a defined
  action on expiry. Do not block on a subprocess that is still downloading,
  building or starting while the session budget runs out.
- Before yielding, make the required end state observable: poll the real
  interface with a bounded readiness loop, confirm the observable condition it
  names (not partial startup output), and leave no required work pending in the
  background.
- Once the deliverables exist and the local acceptance check passes, conclude.
  Do not open another round of unbounded confirmation.

## 3. Cover the graded domain; validate your own tools

- Derive the check matrix from the interface the task names: for every
  parameter/domain regime it mentions, exercise the success path as well as the
  error path. A suite that only covers one regime (one input class, or only
  error branches) leaves the graded call untested.
- When the task asks for all valid answers, enumerate candidates exhaustively
  (every legal move/state/pairing class the rules allow) and assert set equality
  over the full candidate space.
- When you hand-roll a replacement for an unavailable library (enumerator,
  parser, checker, sampler), cross-check it against an independently known case
  before trusting it, and treat internally inconsistent or anomalous self-output
  as a defect signal rather than explaining it away.
- Confirm the interpreter/compiler/library versions the task names before relying
  on version-sensitive behaviour.
- A passing check is not enough: inspect margins, diagnose and retune any thin
  margin, then re-verify with a separate from-disk verifier that recomputes the
  metrics from the produced artifacts using a fresh import of the official model.