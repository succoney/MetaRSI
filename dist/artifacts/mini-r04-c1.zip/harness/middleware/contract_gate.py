"""Bounded acceptance-contract re-check gate (control-flow middleware).

Reusable decision-point guard for the dominant failure family in this
workspace: an artifact that is locally self-consistent but graded against a
different acceptance convention (normalization/serialization, evaluated
region, reference key base, units, tolerance). The existing flat skill text
already describes this, but a static prose block buried in the system prompt
is easy to skip when the model is confident it is done.

This middleware hooks the runtime's existing ``before_final`` path (the only
point where the agent is about to stop). The first time a run that has done
meaningful tool work tries to finalize with still-turns-left, it returns one
``continue`` with a short, task-agnostic acceptance checklist. That reuses the
runtime's own bounded continue budget (``_final_continue_max``) and this
module's one-shot latch, so it can fire at most once per run.

Explicit exit conditions (all return None == accept):
  * already fired once in this run (one-shot latch, kept in ctx.state),
  * fewer than 3 executed tool calls (pure Q&A, nothing to re-check),
  * at most 2 turns left (do not spend the tail on a re-check).

No new tools, no task ids, no grading logic.
"""

# Generic contract-recovery checklist. Deliberately task-agnostic so it applies
# to any deliverable: it names the *kinds* of clauses the grader may compare.
FEEDBACK = (
    "Before you finish, do one bounded acceptance re-check against the task's "
    "stated contract (not against your own recomputation). Re-read what the "
    "task says will be checked, then reload your on-disk deliverable and "
    "assert each clause literally: the exact required filename and path; the "
    "serialization/formatting/normalization the checker compares; units and "
    "any reference parameterization, region, or key base it expects; and any "
    "stated tolerance, coverage, or ordering requirement. Prefer an "
    "independent check over one that re-derives your own assumption. If every "
    "clause holds and the artifact is on disk, restate your final answer "
    "without needlessly changing a verified artifact; if a clause fails, fix "
    "it and re-check. Keep this turn short."
)

_MIN_TOOL_CALLS = 3
_MIN_TURNS_LEFT = 2


async def before_final(answer, ctx):
    state = ctx.state["contract_gate"]
    if state.get("asked"):
        return None
    if len(ctx.tool_history) < _MIN_TOOL_CALLS:
        return None
    if ctx.remaining_turns <= _MIN_TURNS_LEFT:
        return None
    state["asked"] = True
    ctx.trace.event(
        "contract_gate_continue",
        turn=ctx.turn,
        tool_calls=len(ctx.tool_history),
        remaining_turns=ctx.remaining_turns,
    )
    return {"action": "continue", "feedback": FEEDBACK}