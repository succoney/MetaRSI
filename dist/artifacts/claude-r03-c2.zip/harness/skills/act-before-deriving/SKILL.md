---
name: act-before-deriving
description: Use when the task names a deliverable path and that artifact does not exist on disk yet, when a task requires a long derivation, design search, reverse-engineering pass or simulation before anything can be written, or whenever you notice you have produced a long response of pure reasoning without a tool call. Enforces persisting a first well-formed artifact and converting every long derivation into short bounded executable steps, so a tight run budget still leaves a graded artifact behind.
---

# Act before deriving

The failure this avoids: a budget is consumed by uninterrupted reasoning or by a
background build, the episode ends, and the statement-named deliverable does not
exist on disk at all.

## Procedure

1. **First tool call names the artifact.** Read the statement and list the exact
   deliverable path(s) it requires. If any of them is absent, your very next
   action is a tool call that creates a first well-formed version of it at that
   path — even a minimal, partial or placeholder-but-structurally-valid version
   is better than none. Do not emit another long reasoning response while the
   named path is empty.
2. **Never two reasoning-only responses in a row.** If the previous response
   contained no tool call and the deliverable is still missing, the next thing
   you do must be a command or a file write. If you cannot express the next step
   as a command or a short file write, split it until you can.
3. **Derive by executing, not by thinking.** Turn a long derivation, design
   search or simulation into a script that is written to disk and run as a tool
   step under an explicit `timeout`. Persist the partial result of each step to
   disk before starting the next one, so any later cut-off still leaves usable
   state. Re-read that on-disk state as the input to the next step rather than
   carrying it entirely in context.
4. **Bound any build, install or download against the work you can finish.**
   State a deadline for it in the same message. Judge progress only by the
   artifact the step is meant to produce, invoked end to end on a trivial input
   with its real exit code — not by a download, a checksum, a log tail or a live
   process. If the deadline passes without the artifact usable, abandon it,
   report the blocked condition with the exact error/version mismatch, and name
   the compatible alternative you checked. Do not end a turn or a session with a
   build, download or poll still running in the background.
5. **Exit condition.** The deliverable exists at the statement-named path, the
   statement's literal acceptance command has been run against it from a fresh
   process, and nothing is running in the background. When that holds, stop —
   do not open another round of exploration, extra variants or confirmation.