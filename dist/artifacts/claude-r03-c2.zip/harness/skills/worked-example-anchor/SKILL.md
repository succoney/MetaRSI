---
name: worked-example-anchor
description: Use before declaring a task complete when the statement contains a worked example, a quoted expected output, or a value/format it leaves implicit (unit or coordinate scale, address base or keyspace, serializer or attribute order, an offset or required clamp before a motif). Anchors the acceptance check on the statement's own example and forces each implicit convention to one value, instead of shipping a convention you chose yourself or a documented caveat.
---

# Worked-example anchor

Most statements contain at least one thing that pins the contract down: a worked
input-to-output example, a quoted literal (a format string, delimiter, path or
unit), or an explicit "running X should give Y". Those anchors are stronger
evidence than anything you derive yourself, and they are the cheapest way to
falsify a convention you picked.

## Procedure

1. **Harvest the anchors.** List every worked example, quoted expected value,
   quoted literal and named path in the statement. Write them into one small
   check script that reads the artifact back from disk in a fresh process and
   asserts each anchor exactly — the same comparison the statement describes,
   including any normalization, ordering, scale or base it implies.
2. **Reproduce each anchor literally.** Every example the statement gives must
   come out of your artifact exactly as stated when driven through the
   statement's own entry point. A check that only validates your own assumptions
   is not this check.
3. **Fix every implicit convention to one candidate.** For each value the
   statement does not state numerically — a unit or coordinate scale, an address
   base or identifier keyspace, a serializer or attribute ordering, a required
   prefix/spacer/suffix, an offset or clamp before a motif — enumerate the
   candidate conventions and keep the one that simultaneously (a) reproduces the
   statement's worked example and (b) is consistent with the structure of the
   object actually graded. Assert it structurally (an explicit regexp or offset
   assertion), not by checking that a substring merely occurs.
4. **Ambiguity is blocking, not a caveat.** If two candidates both fit, the one
   matching the worked example wins; if none fits, or the fit is unresolved,
   keep that as the current blocker and resolve it from the statement's source
   evidence rather than finishing with a note that a judgment call was made. Do
   not report a value on a scale or in a keyspace you have not tied to the
   example.
5. **Exit condition.** Every harvested anchor is reproduced by the on-disk
   artifact, and every implicit convention has been fixed to exactly one
   candidate (or is an explicitly stated unresolved blocker). Then stop.