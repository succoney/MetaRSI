# Task solving

Read the question and any supplied context carefully. Identify the requested
entity or value, check the supporting evidence, and answer concisely. Follow any
explicit output-format requirements. Describe tool use only when it actually
occurred, and distinguish supplied evidence from assumptions.

## Match the grader's acceptance contract

Derive the acceptance contract from the task statement before finishing, and
self-check every emitted value against it: required filenames and paths, exact
serialization and formatting, units, reference parameterization, and any stated
comparison or tolerance. Do not validate only against an oracle or convention
you invented. If the task names a specific tool, normalization, or reference,
reproduce that exact convention. After writing the deliverable, reload it from
disk and assert the acceptance quantities explicitly before declaring success.

## Reproduce the exact comparison contract

A self-check only counts if it mirrors the grader's comparison. Compare
like-to-like: if the contract canonicalizes, parses or normalizes a value on one
side, apply the identical transform to both sides (or compare raw-to-raw); never
normalize only the reference while comparing your raw output, since
formatting-preserving output then reads as a modification that never happened.
Evaluate every graded quantity over the full region the stated rule implies,
including any flanking or overhang context the rule covers, not just the
minimal window you declared. Emit keys, identifiers and units from the current
input's own encoded values instead of re-basing, offsetting or normalizing them
only to resemble a worked example; when the reference convention is not
independently observable, state that residual uncertainty rather than adopting a
self-consistent assumption. Require a non-vacuous comparison basis: assert the
compared sets or regions are nonempty (for example overlapping keys > 0 or
region length > 0) so a coverage or consistency assertion can never pass
vacuously on an empty intersection.

## Enforce hard structural and positional rules

Extract every hard structural or positional rule the task, its format, or its
parser imposes, and assert the finished artifact against each one literally:
required prefix or clamp nucleotides/bytes before a payload site, mandatory
header or sentinel lines, fixed field or record order, minimum/maximum record
counts, allowed alphabets, and any "must start/end with" requirement. A locally
valid artifact still fails if it drops a mandated prefix or breaks a layout
rule, so re-read the written artifact from disk and check each constraint
explicitly instead of assuming your construction method already satisfies it.

## Validate the real invocation, not a weaker proxy

When the task or grader exercises your artifact through an interface, reproduce
that exact interface end-to-end before finishing and confirm the expected
observable result is captured: drive a documented entrypoint with its real
call/await form and argument names (an awaited coroutine, not a synchronous
call that returns None), replay the grader's full interactive sequence
(connect, authenticate/login, run the command, capture its stdout) rather than
a read-only liveness probe, and check the final state the grader will inspect.
Treating "the process starts", "a banner appears", or "the function exists" as
success leaves interface mismatches undetected.

## Budget the deliverable's own runtime and size

The grader runs your deliverable under a fixed per-test timeout and container
limits. Bound sample sizes, iteration counts, problem sizes and emitted output
volume so the deliverable finishes comfortably inside that window while still
producing the required format and precision. If a correct result is produced
only by an invocation that runs near or past the timeout, treat that as a defect
to fix (reduce work per run, cache, or size the workload) rather than a success.