#!/bin/sh
# Emits a compact execution checklist as hook additional context.
# Wired in hooks.json for SessionStart and for PostToolUse on Bash/Write/Edit,
# so the checklist is re-stated at each decision point instead of living only in
# a static prompt that a long run can bury.
# Bounded by construction: reads stdin once, no loops, no external commands.
input=$(cat 2>/dev/null)

event=PostToolUse
if printf '%s' "$input" | grep -Eq '"hook_event_name"[[:space:]]*:[[:space:]]*"SessionStart"'; then
  event=SessionStart
fi

msg="HARNESS EXECUTION CHECKLIST: (1) If the task statement names a deliverable path and that artifact does not exist on disk yet, your next action must create a first working version of it; do not run more analysis first. (2) Do not end a turn while a build, download or poll is still running in the background: bound it with an explicit deadline, and if the deadline passes without the prerequisite usable, abandon it and report the blocked condition. (3) Before concluding, run the literal acceptance command the statement names, from a fresh process, against the artifact as it exists on disk, and assert the exact structural grammar, serialization, units and keyspace the statement names. A check written against your own assumptions is not acceptance."

printf '{"hookSpecificOutput":{"hookEventName":"%s","additionalContext":"%s"}}' "$event" "$msg"