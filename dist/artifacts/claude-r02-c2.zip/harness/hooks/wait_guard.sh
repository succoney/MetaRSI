#!/bin/sh
# PreToolUse guard for the Bash tool (wired in hooks.json).
# Denies the two unbounded-wait shapes that measurably consumed whole runs:
#   * a condition-poll loop that sleeps until an external job finishes
#   * a single tool timeout long enough to outlive the remaining session budget
# Emits a deny decision naming bounded alternatives; otherwise stays silent so
# every other command is allowed unchanged.
# Bounded by construction: reads stdin once, no loops, no external commands
# beyond grep.
input=$(cat 2>/dev/null)
reason=""

if printf '%s' "$input" | grep -Eq '(until|while).{0,400}do.{0,300}sleep'; then
  reason="Blocked by harness wait-guard: an until/while loop that sleeps until an external job finishes can consume the whole run budget after the deliverable already exists. Bounded alternatives: start the job with run_in_background and check the real interface with one short command; or poll with a capped loop, for example: for i in 1 2 3 4 5; do <check> && break; sleep 2; done, and decide explicitly what to do when the attempts are exhausted. If the required artifact already exists and its acceptance check passes, conclude instead of waiting."
elif printf '%s' "$input" | grep -Eq '"timeout"[[:space:]]*:[[:space:]]*[0-9]{7,}'; then
  reason="Blocked by harness wait-guard: a single Bash timeout of 1,000,000 ms or more can outlive the remaining session budget and lose a deliverable that is already complete. Use a bounded timeout (for example 120000) with a capped retry loop, or run the long job with run_in_background and poll the real interface with short bounded checks."
fi

[ -z "$reason" ] && exit 0

printf '{"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"deny","permissionDecisionReason":"%s"}}' "$reason"