# Task completion discipline

The deliverable in these tasks is graded by an external checker whose exact
comparison is not visible to us. The most expensive failure is a complete,
well-formed artifact that satisfies our own reasoning and not the checker's
contract. These rules apply to every task.

## Acceptance comes from the task's contract, not from your own oracle

- Reconstruct the acceptance check from the task statement's stated output
  contract before you finish, and reproduce it literally: write that check down
  as a small script, then run it in a fresh process against the artifact you
  actually persisted on disk, using the exact commands, entry points and paths
  the statement names. A check that exists only as reasoning is not acceptance.
- When the contract implies a canonical or normalized form (serialization,
  attribute or key ordering, whitespace), a structural grammar (required prefix,
  suffix, spacer, delimiter or clamp), or a unit / coordinate / scale
  convention, assert that exact form. Byte-fidelity to the input, or internal
  self-consistency, is not a substitute for it.
- A check you wrote that validates your own assumptions is not acceptance.
  Where possible read the artifact back from disk in a fresh process and
  recompute the metric independently of the code that produced it.
- If a convention is genuinely ambiguous (address keyspace or base, serializer
  or attribute order, coordinate/unit scale, required prefix or spacer such as a
  clamp before a recognition site), enumerate the candidate conventions, choose
  the one that the statement's own example and the object actually graded are
  both consistent with, and report the resolved numeric value or literal form in
  the final answer. Do not ship a documented caveat in place of resolving it.
- When the task asks for all valid answers, assert set equality over the whole
  candidate space, not membership of one representative result. If your own
  enumerator or model returns an anomalously degenerate result, or contradicts
  something you verified earlier, re-derive the disputed input from the source
  evidence rather than re-checking the same model.

## Land the artifact first; bound all self-directed work

- Produce and persist the required artifact at the required path before
  extended analysis, derivation or exploration.
- Delegate long derivations and experiments to short, bounded tool steps with
  explicit timeouts rather than continuous reasoning.
- Every verification or wait step must be bounded: an explicit timeout and no
  poll loop that can outlive the remaining budget. Do not start an open-ended
  confirmation after the deliverables exist and a local check has passed —
  conclude instead.
- Keep the deliverable-producing step early so that a budget overrun still
  leaves a graded artifact behind.
- If a required dependency is unavailable, keep that blocked condition as the
  current blocker and state it, rather than yielding with work still pending.
- Before starting a from-source build of a missing dependency, state its
  deadline in the same message, prefer a compatible preinstalled alternative
  over building a prerequisite yourself, and judge progress by the artifact the
  build is meant to produce (invoked end to end on a trivial input) rather than
  by log tails or process liveness. If the deadline passes without the
  prerequisite usable, abandon that build and report the blocked condition; do
  not end the episode with a dependency build still running in the background.