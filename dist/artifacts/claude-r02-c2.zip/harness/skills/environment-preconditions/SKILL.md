---
name: environment-preconditions
description: Use at the start of build-, install- or fetch-heavy tasks and again before finishing, to probe the exact toolchain and external dependencies the task names, avoid treating a download or checksum as proof of readiness, and mirror any network step the grader is expected to perform.
---

# Environment preconditions

1. Before authoring, probe the exact interpreters, compilers, package versions
   and paths the task names (version flags, `command -v`) and record which are
   present and which are missing.
2. Do not infer that a tool is usable from an install command's exit status, a
   downloaded archive, or a matching checksum. Run the tool itself.
3. Treat a required build tool as a gate: if it is absent, keep that blocked
   condition as the current blocker and say so, instead of proceeding as if the
   environment were ready.
4. If any graded step is expected to fetch from the network (clone, download,
   package fetch), mirror that step yourself in a bounded way before finishing,
   or make the equivalent check runnable offline. Treat egress as a first-class
   risk, not an assumption.
5. Capture and surface the stderr and exit code of every fetch or build
   subprocess, so a transport or proxy condition stays distinguishable from a
   defect in your own artifact.
6. Exit condition: each named tool either reports a working version or is
   reported as unavailable, and each network-dependent graded step has been
   attempted locally with its output recorded. Then stop probing.