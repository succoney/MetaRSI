---
name: interface-coverage-check
description: Use after writing a deliverable and before declaring the task complete, to derive the verification matrix from the public interface the checker exercises. Covers the success path for every named parameter regime, assertions on returned values, set equality for "all valid answers" outputs, and cross-checks of any hand-rolled replacement for an unavailable library.
---

# Interface coverage check

Goal: the checks we run must exercise the same input classes the checker does,
not only the classes that are convenient to write.

1. From the task statement, list the public entry points and every parameter
   regime, domain or boundary it names (for example bounded vs unbounded
   support, positive sample counts, concurrency limits, valid vs invalid
   inputs, units and signs).
2. For each entry point, run the success path for every named regime with a
   valid invocation and assert on the returned values, not only on raised
   errors or non-zero exit codes.
3. Use the exact invocation shape the statement describes — same argument
   types, same units, same signs — rather than a nearby variant that happens
   to pass.
4. If the task asks for all valid answers, assert set equality over the full
   candidate space (or an independently derived superset), not membership of a
   single result.
5. If an unavailable library was replaced by your own enumerator, parser or
   checker, cross-check it against an independently known case (a closed-form
   value, a small brute-force enumeration, or the library's documented example)
   before trusting it. Treat an internally inconsistent output of your own tool
   as a defect signal to investigate, not something to explain away.
6. Exit condition: every named regime has at least one passing success-path
   assertion, and any claim about the whole answer space is asserted as a set
   relation. Stop when this holds; do not keep adding runs of the same regime.