"""Decision-pin middleware.

Records conclusions the agent derives from concrete evidence artifacts and gates
finalization so an evidence-grounded conclusion cannot be silently reversed by
speculation. It uses the existing ``before_llm`` / ``before_final`` lifecycle
hooks only; no runtime change is required.

Mechanism (matches the assigned hypothesis):

1. ``before_llm`` scans the most recent assistant text (content + reasoning) for
   *commitment* statements ("top/best model is X", "FINAL: Y", "... = Z"). When
   the committed value also appears in a recent tool-result artifact, the claim
   is recorded as a pin ``{subject, value, evidence_ref, turn, ...}`` in
   ``ctx.state['decision_pin']`` (trace ``decision_pin_write``).
2. When a later assistant text or the draft final answer asserts a *conflicting*
   value for the same kind of quantity and no tool call made *after* the pin
   produced new evidence that actually contradicts the pin (same subject), the
   middleware asks the agent to re-cite the pinned evidence instead of flipping
   (``before_llm`` directive; ``before_final`` one-shot ``action=continue`` with
   the pinned evidence re-injected).

Everything is defensive: any failure leaves the message list / answer untouched,
and the module never raises out of a hook.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

try:  # optional: only used to read tunables from agent.yaml
    import yaml
except Exception:  # pragma: no cover - yaml is a harness dependency
    yaml = None


DEFAULTS = {"enabled": True, "max_pins": 8, "window": 6, "max_blocks": 1}

# ---------------------------------------------------------------------------
# Patterns
# ---------------------------------------------------------------------------

_STOP = {
    "the", "and", "for", "that", "this", "with", "from", "have", "has", "had",
    "was", "were", "are", "is", "be", "been", "it", "its", "of", "to", "in",
    "on", "at", "as", "an", "a", "or", "if", "then", "than", "so", "but",
    "would", "should", "could", "will", "can", "may", "not", "no", "which",
    "who", "what", "when", "where", "top", "best", "final", "answer", "mean",
    "model", "score", "task", "tasks", "all", "only", "per", "over", "we",
    "i", "you", "they", "he", "she", "them", "our", "your", "their", "there",
    "here", "also", "into", "by", "do", "does", "did", "get", "got", "now",
    "full", "coverage",
}

_CUE_FAMILY = {
    "top": "best", "best": "best", "winner": "best", "leading": "best",
    "highest": "best", "champion": "best", "strongest": "best",
    "final": "answer", "answer": "answer", "conclusion": "answer",
    "concluded": "answer", "conclude": "answer", "decided": "answer",
    "decision": "answer", "submit": "answer", "submitting": "answer",
    "select": "answer", "selected": "answer", "choose": "answer",
    "chosen": "answer", "pick": "answer", "picked": "answer",
}
_CUE_RE = re.compile(
    r"\b(" + "|".join(sorted(_CUE_FAMILY, key=len, reverse=True)) + r")\b", re.I
)

# slash-joined identifiers, e.g. Qwen/Qwen3-Embedding-8B, GritLM/GritLM-7B
_SLASH_ENTITY_RE = re.compile(
    r"[A-Za-z][A-Za-z0-9]*(?:[._-][A-Za-z0-9]+)*"
    r"/[A-Za-z][A-Za-z0-9._-]+"
)
# single tokens with an internal separator, e.g. Qwen3-Embedding-8B
_IDENT_RE = re.compile(r"\b[A-Za-z][A-Za-z0-9]*(?:[-._][A-Za-z0-9]+)+\b")
_NUMBER_RE = re.compile(r"(?<![\w.])-?\d+\.\d+")

_FILE_EXTS = (
    ".c", ".h", ".py", ".r", ".txt", ".md", ".json", ".yaml", ".yml", ".sh",
    ".js", ".ts", ".html", ".htm", ".css", ".csv", ".log", ".tar", ".gz",
    ".zip", ".o", ".so", ".bin", ".xml", ".rs", ".go", ".java", ".rb", ".php",
)


def _load_config(ctx: Any) -> dict:
    cached = ctx.state.get("decision_pin_cfg")
    if isinstance(cached, dict):
        return cached
    cfg = dict(DEFAULTS)
    try:
        candidates = []
        here = Path(__file__).resolve().parent.parent / "agent.yaml"
        candidates.append(here)
        root = getattr(getattr(ctx, "workspace", None), "root", None)
        if root is not None:
            candidates.append(Path(root) / "agent.yaml")
        raw = None
        for path in candidates:
            if path.is_file():
                raw = path.read_text(encoding="utf-8")
                break
        if raw and yaml is not None:
            data = yaml.safe_load(raw) or {}
            block = data.get("decision_pin")
            if isinstance(block, dict):
                for key in DEFAULTS:
                    if key in block:
                        cfg[key] = block[key]
    except Exception:
        pass
    # Coerce / clamp
    try:
        cfg["enabled"] = bool(cfg.get("enabled", True))
        cfg["max_pins"] = max(0, int(cfg.get("max_pins", DEFAULTS["max_pins"])))
        cfg["window"] = max(0, int(cfg.get("window", DEFAULTS["window"])))
        cfg["max_blocks"] = max(0, int(cfg.get("max_blocks", DEFAULTS["max_blocks"])))
    except Exception:
        cfg = dict(DEFAULTS)
    ctx.state["decision_pin_cfg"] = cfg
    return cfg


def _pins(ctx: Any) -> list:
    pins = ctx.state.get("decision_pin")
    if not isinstance(pins, list):
        pins = []
        ctx.state["decision_pin"] = pins
    return pins


# ---------------------------------------------------------------------------
# Text extraction
# ---------------------------------------------------------------------------

def _norm(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").strip().lower())


# Split on newlines and sentence punctuation, but never inside a decimal
# number such as 0.6408 (do not split a '.' that sits between digits).
_SENTENCE_SPLIT_RE = re.compile(r"(?:\n+|(?<![0-9])[.!?;]+(?![0-9]))")


def _sentences(text: str) -> list:
    parts = _SENTENCE_SPLIT_RE.split(text or "")
    return [p for p in (s.strip() for s in parts) if p]


def _valid_entity(tok: str) -> bool:
    t = tok.strip("`.,;:()[]{}\"'")
    if len(t) < 3 or len(t) > 90:
        return False
    low = t.lower()
    if low.endswith(_FILE_EXTS):
        return False
    if "//" in t or t.startswith("http"):
        return False
    return any(ch.isdigit() for ch in t)


def _value_matches(sentence: str) -> list:
    found = []
    for m in _SLASH_ENTITY_RE.finditer(sentence):
        if _valid_entity(m.group(0)):
            found.append((m.start(), m.end(), m.group(0), "entity"))
    for m in _IDENT_RE.finditer(sentence):
        tok = m.group(0)
        if _valid_entity(tok):
            found.append((m.start(), m.end(), tok, "entity"))
    for m in _NUMBER_RE.finditer(sentence):
        found.append((m.start(), m.end(), m.group(0), "number"))
    found.sort(key=lambda x: x[0])
    # drop overlaps (prefer the earlier/longer match)
    deduped = []
    last_end = -1
    for start, end, tok, kind in found:
        if start < last_end:
            continue
        deduped.append((start, end, tok, kind))
        last_end = end
    return deduped


def _nearest_value(sentence: str, after: int):
    matches = _value_matches(sentence)
    if not matches:
        return None
    for start, end, tok, kind in matches:
        if start >= after:
            return {"display": tok, "key": _norm(tok), "kind": kind, "span": (start, end)}
    start, end, tok, kind = matches[-1]
    return {"display": tok, "key": _norm(tok), "kind": kind, "span": (start, end)}


def _subject_words(sentence: str, cue_span, value_span, value_display: str) -> list:
    words = []
    value_low = value_display.lower()
    for m in re.finditer(r"[A-Za-z][A-Za-z0-9_]{2,}", sentence):
        if cue_span and m.start() < cue_span[1] and m.end() > cue_span[0]:
            continue
        if value_span and m.start() < value_span[1] and m.end() > value_span[0]:
            continue
        w = m.group(0).lower()
        if w in _STOP or w in value_low:
            continue
        if w not in words:
            words.append(w)
    return words[:5]


def _commitments(text: str) -> list:
    """Return commitment records found in ``text``."""
    out = []
    seen = set()
    for sentence in _sentences(text):
        cues = list(_CUE_RE.finditer(sentence))
        if not cues:
            continue
        cue = cues[0]
        family = _CUE_FAMILY.get(cue.group(1).lower(), "answer")
        value = _nearest_value(sentence, cue.end())
        if not value:
            continue
        subject = _subject_words(sentence, cue.span(), value["span"], value["display"])
        key = (value["kind"], value["key"], tuple(subject), family)
        if key in seen:
            continue
        seen.add(key)
        out.append(
            {
                "subject": subject,
                "value_display": value["display"].strip("`.,;:()[]\"'"),
                "value_key": value["key"].strip("`.,;:()[]\"'"),
                "kind": value["kind"],
                "family": family,
            }
        )
    return out


def _raw_candidates(text: str) -> list:
    """Plain value tokens (any sentence) treated as assertions with no subject.

    Used for the final-answer gate so a bare reply such as a model id is still
    compared against recorded pins even without an explicit commitment cue.
    """
    out = []
    seen = set()
    for sentence in _sentences(text):
        for _start, _end, tok, kind in _value_matches(sentence):
            clean = tok.strip("`.,;:()[]\"'")
            key = _norm(clean)
            if not key or (kind, key) in seen:
                continue
            seen.add((kind, key))
            out.append(
                {
                    "subject": [],
                    "value_display": clean,
                    "value_key": key,
                    "kind": kind,
                    "family": "answer",
                }
            )
    return out


def _record_text(rec: Any) -> str:
    parts = []
    name = getattr(rec, "executed_name", None) or getattr(rec, "requested_name", "")
    parts.append(str(name))
    preview = getattr(rec, "result_preview", None)
    if isinstance(preview, str):
        parts.append(preview)
    for attr in ("requested_args", "executed_args"):
        val = getattr(rec, attr, None)
        if isinstance(val, dict):
            try:
                parts.append(json.dumps(val, ensure_ascii=False, default=str))
            except Exception:
                parts.append(str(val))
    return "\n".join(parts)


def _recent_records(ctx: Any, window: int, *, after_turn: int | None = None) -> list:
    out = []
    for rec in getattr(ctx, "tool_history", []) or []:
        turn = getattr(rec, "turn", 0)
        if after_turn is None:
            if window >= 0 and turn < ctx.turn - window:
                continue
        else:
            if turn <= after_turn:
                continue
        out.append(rec)
    return out


def _evidence_backed(ctx: Any, value: dict, cfg: dict) -> tuple[bool, str]:
    needle = value.get("value_key") or value.get("key") or ""
    for rec in _recent_records(ctx, cfg["window"]):
        text = _norm(_record_text(rec))
        if needle and needle in text:
            ref = "%s@turn%s#%s" % (
                getattr(rec, "executed_name", "") or getattr(rec, "requested_name", ""),
                getattr(rec, "turn", "?"),
                getattr(rec, "seq", "?"),
            )
            return True, ref
    return False, ""


def _allowed_by_new_evidence(ctx: Any, pin: dict, cand: dict) -> bool:
    """True if a tool call after the pin produced evidence for the new value."""
    needle = cand["value_key"]
    if not needle:
        return False
    subject = set(pin.get("subject") or [])
    for rec in _recent_records(ctx, -1, after_turn=pin.get("turn", 0)):
        text = _norm(_record_text(rec))
        if needle in text and (not subject or any(word in text for word in subject)):
            return True
    return False


def _conflict(pin: dict, cand: dict) -> bool:
    if pin.get("kind") != cand["kind"]:
        return False
    if pin.get("value_key") == cand["value_key"]:
        return False
    ps = set(pin.get("subject") or [])
    cs = set(cand.get("subject") or [])
    if not ps or not cs:
        return True
    if ps & cs:
        return True
    if pin.get("family") == cand.get("family"):
        return True
    return False


# ---------------------------------------------------------------------------
# Pinning / gating
# ---------------------------------------------------------------------------

def _latest_assistant_text(messages: list) -> tuple[str, str]:
    if not isinstance(messages, list):
        return "", ""
    for msg in reversed(messages):
        role = msg.get("role") if isinstance(msg, dict) else getattr(msg, "role", "")
        if role != "assistant":
            continue
        content = msg.get("content") if isinstance(msg, dict) else getattr(msg, "content", "")
        reasoning = (
            msg.get("reasoning_content")
            if isinstance(msg, dict)
            else getattr(msg, "reasoning_content", "")
        ) or ""
        return (content or ""), reasoning
    return "", ""


def _message_digest(content: str, reasoning: str) -> str:
    return _norm(content)[:400] + "\u0000" + _norm(reasoning)[:400]


def _add_pins(ctx: Any, commitments: list, cfg: dict) -> None:
    pins = _pins(ctx)
    for cand in commitments:
        # Never re-pin a value that conflicts with a locked conclusion: a
        # reversal must be justified by NEW post-pin evidence, not by re-adding
        # an old artifact.
        if any(_conflict(pin, cand) for pin in pins):
            continue
        backed, ref = _evidence_backed(ctx, cand, cfg)
        if not backed:
            continue
        signature = (cand["kind"], cand["value_key"], tuple(cand["subject"]))
        if any(
            (p.get("kind"), p.get("value_key"), tuple(p.get("subject") or []))
            == signature
            for p in pins
        ):
            continue
        if len(pins) >= cfg["max_pins"]:
            break
        pins.append(
            {
                "subject": list(cand["subject"]),
                "value_display": cand["value_display"],
                "value_key": cand["value_key"],
                "kind": cand["kind"],
                "family": cand["family"],
                "evidence_ref": ref,
                "turn": ctx.turn,
                "injected": False,
                "blocked": 0,
            }
        )
        _trace(
            ctx,
            "decision_pin_write",
            value=cand["value_display"],
            kind=cand["kind"],
            subject=" ".join(cand["subject"]),
            evidence_ref=ref,
            turn=ctx.turn,
        )


def _directive(pin: dict, cand: dict) -> str:
    return (
        "Before changing a previously recorded, evidence-grounded conclusion, "
        "re-verify and re-cite the evidence.\n"
        "Pinned conclusion: %s (evidence: %s, recorded at turn %s).\n"
        "Your latest statement asserts a conflicting value: %s.\n"
        "Do not override an evidence-backed conclusion on speculation. Either "
        "(a) keep the pinned value after re-citing its evidence, or (b) first "
        "run a tool call that produces NEW evidence about the SAME quantity "
        "which actually contradicts the pin. If no such evidence exists, "
        "restore the pinned value."
        % (
            pin.get("value_display", ""),
            pin.get("evidence_ref", ""),
            pin.get("turn", "?"),
            cand.get("value_display", ""),
        )
    )


def _trace(ctx: Any, event: str, **fields: Any) -> None:
    try:
        ctx.trace.event(event, **fields)
    except Exception:
        pass


def _cfg_enabled(ctx: Any) -> dict:
    cfg = _load_config(ctx)
    return cfg


async def before_llm(messages: list, ctx: Any) -> list:
    try:
        cfg = _cfg_enabled(ctx)
        if not cfg["enabled"]:
            return messages
        content, reasoning = _latest_assistant_text(messages)
        text = (content or "") + "\n" + (reasoning or "")
        digest = _message_digest(content, reasoning)
        last = ctx.state.get("decision_pin_last_msg")
        if text.strip() and digest != last:
            ctx.state["decision_pin_last_msg"] = digest
            commitments = _commitments(text)

            # 1) Gate: reconcile the latest assertions against existing pins
            #    *before* recording new ones, so a speculative reversal cannot
            #    be laundered into a fresh pin.
            pins = _pins(ctx)
            for pin in pins:
                if pin.get("injected"):
                    continue
                for cand in commitments:
                    if not _conflict(pin, cand):
                        continue
                    if _allowed_by_new_evidence(ctx, pin, cand):
                        _trace(
                            ctx,
                            "decision_pin_reversal_allowed",
                            value=cand.get("value_display", ""),
                            evidence_ref=pin.get("evidence_ref", ""),
                        )
                        pin["injected"] = True
                        break
                    pin["injected"] = True
                    directive = _directive(pin, cand)
                    if isinstance(messages, list):
                        messages = list(messages) + [
                            {"role": "user", "content": directive}
                        ]
                    _trace(
                        ctx,
                        "decision_pin_redirect",
                        value=cand.get("value_display", ""),
                        pinned=pin.get("value_display", ""),
                        evidence_ref=pin.get("evidence_ref", ""),
                        turn=ctx.turn,
                    )
                    break

            # 2) Record new evidence-grounded conclusions as pins.
            _add_pins(ctx, commitments, cfg)
        return messages
    except Exception as exc:  # never break the loop
        _trace(ctx, "decision_pin_error", where="before_llm", error=str(exc))
        return messages


async def before_final(candidate: str, ctx: Any):
    try:
        cfg = _cfg_enabled(ctx)
        if not cfg["enabled"]:
            return None
        pins = _pins(ctx)
        if not pins:
            return None
        text = candidate or ""
        candidates = _commitments(text) + _raw_candidates(text)
        for pin in pins:
            for cand in candidates:
                if not _conflict(pin, cand):
                    continue
                if _allowed_by_new_evidence(ctx, pin, cand):
                    _trace(
                        ctx,
                        "decision_pin_reversal_allowed",
                        value=cand.get("value_display", ""),
                        evidence_ref=pin.get("evidence_ref", ""),
                        stage="before_final",
                    )
                    continue
                if pin.get("blocked", 0) >= cfg["max_blocks"]:
                    continue
                pin["blocked"] = pin.get("blocked", 0) + 1
                feedback = _directive(pin, cand)
                _trace(
                    ctx,
                    "decision_pin_block",
                    value=cand.get("value_display", ""),
                    pinned=pin.get("value_display", ""),
                    evidence_ref=pin.get("evidence_ref", ""),
                    count=pin["blocked"],
                )
                return {"action": "continue", "feedback": feedback}
        return None
    except Exception as exc:
        _trace(ctx, "decision_pin_error", where="before_final", error=str(exc))
        return None